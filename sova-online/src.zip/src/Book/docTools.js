// *** *** ***
//
//	docTools.js
//	aon 22 feb 2018
//
// *** *** ***
import React from 'react';
import Util from './common/Util';

export const addNo = doc => {
	let lsn = doc.getField('ADDNO').split('\n'); //_
	let lsd = doc.getField('ADDDA').split('\n'); //_
	let s = '';

	lsn.forEach ( (it, i) => { s += it.trim() ? it + ' ' + Util.dtRus(lsd[i]) + '\n' : ''; }); //_
	doc.dlg.inputBox('Введите: номер-пробел-дата (П-125 17,07,2018)', s, 'Изменить дополнительный номер')
		.then( res => {
		    let nn = '';
		    let dd = '';
		    res.replace(/,/g, '.').split('\n').forEach ( it => { //_
		        let s = it.trim();
		        while( s.includes('  ') ) s = s.replace(/ {2}/g, ' ');
		        if ( s ) {
			        let v = Util.partition(s, ' ');
			        nn += v[0] + '\n'; //_
			        dd += v[1] + '\n'; //_
				}
		    });
		    doc.setField('ADDNO', nn ? nn.slice(0, -1) : '');
		    doc.setField('ADDDA', dd ? dd.slice(0, -1) : '');
		})
		.catch( _ => {} );
};
//**********

export const docSN = doc => {
	let nono = doc.getField('Main') === '1' ? '0' : '1'; // '0' - rkck, '1' - register
	if ( doc.getField('docNo') ) {
		doc.msg.box('\nПоле номера уже заполнено.\n\nДля изменения номера нажмите "Ввести №".\n\n\nДля корректировки порядкового номера нажмите\nкнопку "Настроить №"',
			'ПРИСВОИТЬ ПОРЯДКОВЫЙ НОМЕР',
			['ОК+', 'Ввести №|O', 'Настроить №|N', 'Отмена']
			)
			.then ( res => {
				if ( res === 'O' ) {
					doc.dlg.inputBox('Введите новое значение №', doc.getField('docNo'), 'Изменить номер')
						.then ( res => doc.setField('docNo', res) )
						.catch( _ => doc.setFocus(doc.focus) );
        		}
				else if (res === 'N') {
					let data = `sno?${doc.dbAlias}&get${nono}`;
					fetch('/action', { method: 'post', body: data, credentials: 'include' } )
						.then ( response => response.text() )
						.then ( text => {
							doc.dlg.inputBox('Введите номер последнего зарегистрированного документа\n и нажмите Enter', text, 'Настройка порядкового номера')
								.then ( res => {
									if ( res && !isNaN(Number(res)) ) {
										data = `sno?${doc.dbAlias}&set${nono}¤${res}`; //_
										fetch('/action', { method: 'post', body: data, credentials: 'include' } )
											.then(res => res.text())
											.then(res => doc.msg.box('Сохранен последний номер: ' + res, 'Настройка номера'))
											.catch(res => doc.msg.error('\n' + data +'\n\n' + res.message, 'Ошибка при запросе номера'))
									}
									else {
										doc.msg.box('Недопустимый символ', 'Настройка номера');
									}
								})
								.catch( _ => doc.setFocus(doc.focus) );
						})
						.catch( err => doc.msg.error(err.message, 'Ошибка при запросе номера') );
				}
			})
			.catch( _ => doc.setFocus(doc.focus) );
	}
	else {
		let data = `sno?${doc.dbAlias}&inc${nono}`;
		fetch('/action', { method: 'post', body: data, credentials: 'include' } )
			.then(res => res.text())
			.then(res => {
				if ( res.endsWith('.') ) {
					if ( doc.getField('Main') ) {
						let gr = doc.getField('grounds');
						doc.setField('docNo', res + (gr ? gr.split('\n').length + 1 : '1') ) //_
					}
					else
						doc.setField('docNo', res.slice(0, -1));
				}
				else
					doc.setField('docNo', res);

				if ( nono === '0' && doc.getField('form').toLowerCase() === 'rkckg' && window.rnnGroup )
                	window.rnnGroup(doc, true);

				// doc.setFocus(doc.focus); // по <alt-1> не нужно сбивать фокус
			})
			.catch( err => doc.msg.error(err.message, 'Ошибка при запросе номера') );
	}
};
//**********

export const searchByCorr = doc => {
	if (doc.dlg.state.isOpen) {
		console.log('searchByCorr: doc.dlg.state.isOpen');
		return;
	}

	doc.dlg.show (
		'Поиск по заявителю и району',	// title
		{ SBC_TEXT1: doc.getField('fromCorr') || doc.getField('toCorr'), SBC_TEXT2: doc.getField('rnn') }, // fieldValues
		{ style: {width:'90vw', minWidth: '600px', top: '5%', height: '90vh', minHeight: '420px'}, // стиль всего диалога
			cmCancel: _ => doc.setFocus(doc.focus) // кнопк "cancel" еще м.б. кнопка OK (cmButton)
	 	},
		{ width:'100%', height: '86vh', overflow: 'hidden'}, // стиль области данных
		[ [ // описание секции flist
			{ rowStyle: {width: 'auto', padding: '5px 0', margin: '5px auto 5px', background: '#eee', border: '0 solid #aaa', borderWidth: '0 2px 2px 0' } },
			Util.label('Заявитель', 0, {paddingLeft: 20}),
			{field: ['SBC_TEXT1', 'tx'], style: {width: '60mm'}},
			Util.label('Район', 0, {paddingLeft: 20}),
			{field: ['SBC_TEXT2', 'tx'], style: {width: '60mm'}},
			Util.label('', '20px'),
			{_teg: 'button', _div: 1, text: 'поиск', _cmd: 'SBC', attributes: {className:'svTop', style: {width: '17mm'}, btnClick: _ => {
				doc.dlg.dumb.sbc.setValue(<div className="spinner"/>);
				doc.dlg.forceUpdate();
				searchRequest(doc, doc.dlg.getField('SBC_TEXT1'), doc.dlg.getField('SBC_TEXT2'))
					.then( vd => {
						doc.dlg.dumb.sbc.setValue(vd);
						doc.dlg.forceUpdate();
					})
					.catch(err => doc.msg.error(err.message))
			} } },
			Util.label('', '20px'),
		  ],
		  [ {dumb: 'sbc', xValue: <div className="spinner"/>} ]
		],
		'SBC_TEXT1', // set focus
		'BTN_SBC' // нажать кнопу по Enter
	);
	searchRequest(doc, doc.getField('fromCorr') || doc.getField('toCorr'), doc.getField('rnn'))
		.then( vd => {
			doc.dlg.dumb.sbc.setValue(vd);
			doc.dlg.forceUpdate();
		})
		.catch(err => doc.msg.error(err.message));
};

//**********

const searchRequest = (doc, corr, rnn) => new Promise((ok, errReq) => {
	let data = 'search4corr?' + [doc.dbAlias, corrFV(corr).trim(), rnn.trim()].join('&');
	// let data = 'search4corr?' + [doc.dbAlias, '', ''].join('&');
	fetch('/action', { method: 'post', body: data, credentials: 'include' } )
		.then(res => res.json())
		.then( viewData => {
			let rows = viewData.map( (it, i) => renderRow(doc, it, i) );
			if ( rows.length > 1 || rows[0] ) {
				ok(
					<div style={{overflow: 'hidden'}}>
						<div style={{height:'80vh', overflow: 'auto' }}>
							<table className="sbcTable">
								<colgroup>
									<col style={{width: '14%'}}/>
									<col style={{width: '20%'}}/>
									<col style={{width: '9%'}}/>
									<col style={{width: '33%'}}/>
									<col style={{width: '9%'}}/>
									<col style={{width: '15%'}}/>
								</colgroup>
								{rows}
							</table>
						</div>
					</div>);
			}
			else
				ok('Не найдено');
		})
		.catch( err => errReq(err.message) );
});
//**********

const renderRow = (doc, vd, n) => {
	if ( vd[3] === doc.unid )
		return <tbody key={n}><tr><td colSpan="6"/></tr></tbody>;

	let cols;
	try {
		cols = JSON.parse(vd[2].replace(/¤/g, '; ').replace(/\n/g, '; ')); //_
	}
	catch (ex) {
		return <div>{'Ошибка JSON.parse'}<div>{ex}</div><div>{vd[2]}</div></div>;
	}

	let dbaUnid = `${vd[4]}&${vd[3]}`;
	let row = [0,1,2,3,4,5,6].map( (it, i) => {
		switch (i) {
			case 0: return (
				<td key={i}>
					{Util.dtRus(cols[0])}
					<div
						className="openButton"
						title="Просмотр документа"
						onClick={ _ => doc.dlgPreview.docPreview(dbaUnid, doc) }
					>
						{cols.slice(1, 4).join('').replace(/-/gi, '\u2011') || 'без номера'}
					</div>
					{cols[10]}
				</td>);
			case 1: return (
				<td key={i}>
					<b>{cols[9]}</b><br/>
					{cols[4]}
				</td>);
			case 2: return (
				<td key={i}>
					<div className="openButton"
						title="Новое обращение (копировать реквизиты заявителя)"
						onClick={ e => makeLink(doc, e, dbaUnid + '&заявитель') }
					>
						Новое
					</div>
					<div className="openButton"
						title="Повторное обращение (копировать реквизиты, связать документы)"
						onClick={ e => makeLink(doc, e, dbaUnid + '&') }
					>
						повторное
					</div>
				</td>);
			case 3: return (
				<td key={i}>
					{cols[5]}
				</td>);
			case 4: return (
				<td key={i}>
					<div className="openButton"
						title="Связать с текущим документом"
						onClick={ e => makeLink(doc, e, dbaUnid + '&связать') }
					>
						связать
					</div>
					<div className="openButton"
						title="Объединить документ как дубликат"
						onClick={ e => makeLink(doc, e, dbaUnid + '&дубликат') }
					>
						дубликат
					</div>
				</td>);
			case 5: return (
				<td key={i}>
					{cols[6]}
				</td>);
			default:break;
		};
		return null;
	});
	let res = cols[7] || cols[8] ?
		<tr>
			<td colSpan="6" key={7} style={{color: '#048', textAlign: 'left', border: '0 solid #bdf', borderTopWidth: 1}}>
				<b><span>{cols[7].split(' ')[0] + ': '}</span></b>
				<span>{cols[8]}</span>
			</td>
		</tr>
		:
		null;

	return (
		<tbody key={n} style={{background: n%2 ? '#fff' : '#def'}}>
			<tr>{row}</tr>
			{res}
		</tbody>);
};
//**********

const makeLink = (doc, e, dbaUnid) => {
	e.stopPropagation();

	let data = 'fillFields?' + doc.dbAlias + '&' + dbaUnid + '&';
	fetch('/action', { method: 'post', body: data, credentials: 'include' } )
		.then(res => res.json())
		.then( fils => {
			for ( let f in fils ) {
				if ( fils[f] === '--' )
					doc.setField(f, ''); // заодно очистим мусор типа '--'
				else {
					if ( f === 'GROUNDS'  && doc.getField('GROUNDS') ) {	//сохранить старое 'GROUNDS'
						let oldGr = doc.getField('GROUNDS').split('\n'); //_
						fils[f].replace(/¤/g, '\n').split('\n').forEach( it => { //_
							if ( !oldGr.includes(it) )
								oldGr.push(it);
						});
						doc.setField('GROUNDS', oldGr.join('\n')); //_
					}
					else
						doc.setField(f, fils[f]);
				}
			}
			if ( doc.getField('form').toLowerCase() === 'rkckg' && window.rnnGroup )
				setTimeout( _ => window.rnnGroup(this, true), 10 );
			doc.dlg.btnClick();
		})
		.catch( err => {
			doc.dlg.btnClick();
			doc.msg.error(err);
		});
};
//**********

const corrFV = corr => {
    let ss = corr.toLowerCase();
    let s = corr.replace(/и др$/gi, '').replace(/\+/gi, '').replace(/;/gi, ',').trim();
    ['и др.', 'и другие', '(', 'в интересах', 'в отношении', ','].forEach( it => {
        let p = s.toLowerCase().indexOf(it);
        if ( p >= 0 )
            s = s.substr(0, p).trim();
    });
    if ( ss.includes('без подписи') || ss.includes('жители ') || ss.includes('группа ') || ss.includes('коллектив ') )
        return s;

    let fio = s.split(' ');
    return fio.length === 3 ? `${fio[0]} ${fio[1].charAt(0)}.${fio[2].charAt(0)}.` : s;
};
//**********
