import React from 'react';
import autoBind from 'react-autobind';

import {spinner} from './common/Spinner';
import {boxing} from './common/boxing';
import MsgBox	from './common/MsgBox';
import DialogBox	from './common/DialogBox';
import Util from './common/Util';
import {addNo, docSN, searchByCorr} from './docTools'

import '../css/form.css';
import '../css/toolbar.css';
import '../css/datepicker.css';
import '../css/spinner.css';
import '../css/MsgBox.css';

class Document extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.util = Util;
		this.tidy = true; // == false при изм данных. Нужен для проверки автоордера при закрытии
		this.viewRefresh = false;
		this.waitLoad = true;
		this.waitSave = false;
		this.toolbar = null;
		this.fileShow = {};
		this.register = {};
		this.dumb = {};
		this.hideNewValues = {};
		this.savedText = '';

		this.dbAlias = this.props.dbAlias;
		this.unid = this.props.unid;
		this.rsMode = this.props.rsMode;
		this.cssJsUrl = this.props.cssJsUrl;
		this.loadDocUrl = _ => this.props.newForm ?
			`api.get?newForm&${this.dbAlias}&${this.props.newForm}&${this.rsMode}`
			:
			`api.get?loadDoc&${this.dbAlias}&${this.unid}&${this.rsMode}`;

		// multi-page
		if ( !window.sovaPages ) {
			this.mainDoc = true;
			window.sovaPages = {main: {doc: this}};
		}

		this.state = { spinner: false }
	}
	//**********

	cmdList = {
		edit: _ => this.cmdEdit(),
		save: _ => this.cmdSave(),
		close: _ => this.cmdClose(),
		saveClose: _ => this.cmdSave(true), // флаг ЗАКРЫТЬ после сохранения
		prn: _ => this.cmdSave(null, true), // флаг ПЕЧАТЬ после сохранения
		docOpen: dbaUnid => Util.xopen('docopen?' + dbaUnid),	// открыть документ
		dbOpen: dba => Util.xopen('dbopen?' + dba),	// открыть журнал
		xopen: url => Util.xopen(url),	// открыть url
		newDoc: dbaAndForm => { // dbaAndForm: RF.AKK/STAT1&reportManager&one
			let [dba, form, one] = dbaAndForm.split('&');	// one: запрет открытия больше отдного нового документа данной формы одновременно
			one ? Util.xopen('newdoc?' + dba + '&' + form) : window.open('newdoc?' + dba + '&' + form);
		},
		docPreView: dbaUnid => this.dlgPreview.docPreview(dbaUnid, this),

		// from docTools.js:
		addNo: _ => addNo(this),			// редактировать доп. номер
		searchByCorr: _ => searchByCorr(this),
		docSN: _ => docSN(this),	// set serial number
		docPreview: dbaUnid => this.dlgPreview.docPreview(dbaUnid, this), // открыть док в режиме превью
	};
	// *** *** ***

	addPage(props) {
		let page = props.page || 'page';
		window.sovaPages[page] = {};
		window.sovaPages[page].props = {...props};
		this.forceUpdate();
	}
	// *** *** ***

	closePage(page) {
		if ( page !== 'main' ) {
			window.sovaPages[page].doc = null;
			window.sovaPages[page] = null;
			delete window.sovaPages[page];
			this.forceUpdate();
		}
	}

	maxPage(page) {
		let d = window.sovaPages[page].doc;
		Util.xopen('docopen?' + d.dbAlias + '&' + d.unid + '&' + d.rsMode);
	}

	dragStart = false;

	dragPage(e) {
		if ( e.buttons === 1 && this.dragStart && this.x1 ) {
			let st = window.sovaPages[this.dragStart].props.frameStyle;
			st.left += e.screenX - this.x1;
			st.top  += e.screenY - this.y1;
			this.x1 = e.screenX;
			this.y1 = e.screenY;
			this.forceUpdate();
			e.stopPropagation();
			e.preventDefault();
		}
	}

	pageMouseUp(e) {
		if (this.dragStart) {
			let st = window.sovaPages[this.dragStart].props.frameStyle;
			st.left += e.screenX - this.x1;
			st.top  += e.screenY - this.y1;
			this.dragStart = false;
			this.forceUpdate();
		}
	}
	// *** *** ***

	componentDidMount() {
		// через .5с включить "Загрузка", если waitLoad=true
		setTimeout(() => { if (this.waitLoad) this.setState({spinner: true}) }, 500 );

		if ( this.props.fieldValues ) { // донные уже в документе
			this.fieldValues = this.props.fieldValues;
			this.isNew = !this.fieldValues.MODIFIED;
			this.printList = this.props.printList;
			if (this.props.owlDebug) {
				console.log('debug: this.props.urlForm', this.props.urlForm);
				Util.jsonByUrl(this.props.urlForm) // загрузка формы
					.then( page => Util.addJsCSS(this.cssJsUrl, _ => this.loadForm(page)) );
				}
			else
				Util.jsonByUrl(this.props.urlForm) // загрузка формы
					.then( page => Util.addJsCSS(this.cssJsUrl, _ => this.loadForm(page)) )
					.catch ( err => this.loadError(err + '\n\ndoc.props.urlForm:' + this.props.urlForm) );
		}
		else {
			if (this.props.owlDebug) {
				console.log('debug:this.loadDocUrl():', this.loadDocUrl());
				Util.jsonByUrl(this.loadDocUrl()) // загрузка данных
					.then( jsn => {
						this.setDocProps(jsn);
						return jsn.urlForm ? Util.jsonByUrl(jsn.urlForm) : null; // загрузка формы
					})
					.then( page => Util.addJsCSS(this.cssJsUrl, _ => this.loadForm(page)) );
				}
			else
				Util.jsonByUrl(this.loadDocUrl()) // загрузка данных
					.then( jsn => {
						this.setDocProps(jsn);
						return jsn.urlForm ? Util.jsonByUrl(jsn.urlForm) : null; // загрузка формы
					})
					.then( page => Util.addJsCSS(this.cssJsUrl, _ => this.loadForm(page)) )
					.catch ( err => this.loadError(err + '\n\nurl: ' + this.loadDocUrl) );
		}
	}
	//**********

	setDocProps = dp => {
		this.fieldValues = {...dp.data};
		this.isNew = !dp.data.MODIFIED;
		this.printList = dp.printList;
		this.rsMode = dp.rsMode; // перезаписать (может отличаться от отправленной)
		this.cssJsUrl = dp.cssJsUrl;
	}
	//**********

	loadForm = page => {
		this.waitLoad = false;
		this.sova = ( window.sovaActions && window.sovaActions[this.getField('form').toLowerCase()] ) || {};
		this.sova.init && this.sova.init(this);

		this.children = page.children;
		this.pageAttr = page.attributes || {};
		this.focus = ( this.rsMode === 'edit' && this.pageAttr.focus ) || 'BTN_CLOSE';
		this.className = this.pageAttr.className || '';
//		this.style = {...this.pageAttr.style, opacity: '0.2', transition: 'opacity 50ms ease', ...this.props.style}; // this.props.style - при открытии в диалоге (preView)
		this.style = {...this.pageAttr.style, ...this.props.style}; // this.props.style - при открытии в диалоге (preView)

		this.setState({spinner: false, rsMode: this.rsMode, readOnly: this.pageAttr.readOnly || !(['edit', 'admin'].includes(this.rsMode)) });
		if (!this.init2
			&& window.sovaActions
			&& window.sovaActions[this.getField('form').toLowerCase()]
			&& window.sovaActions[this.getField('form').toLowerCase()].init2 ) {
				window.sovaActions[this.getField('form').toLowerCase()].init2(this);
				this.init2 = true;
			}
		this.setFocus(this.focus);
//		this.style = {...this.style, opacity: '1', transition: 'opacity 0.4s ease'};
//		this.forceUpdate();
	}
	//**********

	loadError = mess => {
		let s = 'dbAlias: ' + this.dbAlias + '\nunid: ' + this.unid + '\n\n' + mess;
		if ( this.msg )
			this.msg.error(s, 'Ошибка открытия документа');
		else {
			this.errMsg = <div>{ s.split('\n').map( (it,i) => <div key={i}>{it || '\u00a0'}</div> ) }</div>;
			console.log('Ошибка открытия документа:' + s);
		}
		this.waitLoad = false;
		this.setState({spinner: false});
	};
	//**********

	cmdEdit() {
		if ( this.state.rsMode !== 'readOnly' ) {
			window.location.href = 'docopen?' + this.dbAlias + '&' + this.unid + '&edit';
		}
	}
	//**********

	cmdClose = _ => !this.waitSave && this.closeDoc(false);

	//**********

	cmdPrn() {
		if ( ! this.flagPrint  )
			return;

		this.flagPrint = false;

		if ( this.fieldValues.FORM.endsWith('.print') || !this.printList )
			return window.print();

		let ls = this.printList.replace(/¤/g, '\n').split('\n'); //_
		if ( this.fieldValues.FORM === 'o-' || ls.length === 2)
			return Util.xopen('docopen?' + this.dbAlias + '&' + this.unid + '&read&' + ls[1].split('|').slice(-1)[0]);

		this.msg.list(ls.slice(1), "Выберите форму для печати", {}, true) // true - small
			.then( res => {
				let form = res.indexOf('|') >= 0 ? Util.partition(res, '|')[1] : res;
				Util.xopen('docopen?' + [
					this.dbAlias,
					res.startsWith('rk') ? ls[0] : this.unid,
					'read',
					form].join('&') );
				this.setFocus('BTN_CLOSE');
				})
			.catch( _ => this.setFocus('BTN_CLOSE') );

	}
	//**********

	cmdSave(close, print=null) {
		if ( this.waitSave )
			return;

		this.waitSave = true;

		this.flagClose = close;
		this.flagPrint = print;
		if ( this.state.readOnly || !this.getNewValues(false) || this.getField('noSave') ) { // режим чтения или нет измененных полей или есть непустое поле noSave
			this.waitSave = false;
			return print ? this.cmdPrn() : close && this.props.closeDoc(this, this.tidy);
		}

		this.validate()
			.then( _ => {
			// через .5с включить Spinner, если waitSave=true
				setTimeout(() => {if (this.waitSave) this.setState({spinner: true});}, 500 );

				// для файл-шоу запускает startUpload. Если upload не нужен,
				// startUpload() устанавливает fileShow[fs].run=false, в этом случае
				// переходим ко второй части: сохранение полей из всех компонент.
				// Если startUpload() устанавливает fileShow[fs].run=true, cmdSave2 ничего не делает -
				// ждет, когда кончится upload

				for ( let fs in this.fileShow )
					this.fileShow[fs].startUpload();

				this.cmdSave2();
			})
			.catch( _ => {this.waitSave = false;});
	}
	//**********

	validate = _ => new Promise ( (yes, reject) => {

		let sova = this.sova.validate;
		if ( !sova )
			return yes();

		for ( let v in sova )
			if ( v.toLowerCase() !== 'form' ) {
				let er = sova[v](this);
				if ( er || er === 0 ) {
					this.msg.box(er || `Поле "${v}" не заполнено`)
						.then( _ => reject( this.setFocus(v) ) )
						.catch( _ => reject() );
					return;
				}
			}

		for ( let v in sova )
			if ( v.toLowerCase() === 'form' ) {
				sova[v](this)
					.then( _ => yes() )
					.catch( _ => reject(this.setFocus(this.focus)) );
				return;
			}

		return yes();
	});
	// *** *** ***

	getField = (xName, par) => Util.getField(this, xName, par);
	setField = (xName, xValue, par) => Util.setField(this, xName, xValue, par);
	setFocus = xName => Util.setFocus(this, xName);

	// *** *** ***

	changeDropList(xName, alias) {
		let xn = xName.toUpperCase();
		this.register[xn] && this.register[xn].changeDropList && this.register[xn].changeDropList(alias);
	}
	// *** *** ***

	getNewValues(flagSave) {
		if ( this.getField('noSave') )
			return '';

		let jsn = '';

		// получить список новых/удаленных вложений
		for ( let fs in this.fileShow )
			jsn += this.fileShow[fs].getNewValues(flagSave);

		// получить значения скрытых полей, которые были добавлены
		Object.keys(this.hideNewValues).forEach( xName => {
			if ( !(xName in this.fieldValues) )
				jsn += Util.addJson( xName, '', this.hideNewValues[xName] );
		});

		// получить значения скрытых полей, которые были загружены с сервера при открытии документа
		Object.keys(this.fieldValues).forEach( xName => {
			if ( !(xName in this.register) ) {
				let oldValue = this.isNew ? '' : this.fieldValues[xName];
				let newValue = xName in this.hideNewValues ? this.hideNewValues[xName] : this.fieldValues[xName];
				jsn += Util.addJson( xName, oldValue, newValue);
			}
		} );

		// получить значения контролов
		Object.keys(this.register).forEach( xName => {
			if ( this.register[xName].props.type !== 'fd' ) {
				let oldValue = this.isNew ? '' : (this.fieldValues[xName] || '');
				let newValue = this.register[xName].getValue ? this.register[xName].getValue() : (this.fieldValues[xName] || '');
				jsn += Util.addJson( xName, oldValue, newValue);
			}
		} );

		this.tidy = this.tidy && !jsn; // == false при изм данных. Нужен для проверки автоордера при закрытии

		if (jsn) {
			if ( !jsn.includes('"UNID":["') )
				jsn += Util.addJson('UNID', '', this.unid);
			if ( this.fieldValues['REF'] && !jsn.includes('"REF":["') )
				jsn += Util.addJson('REF', '', this.fieldValues['REF']);
		}
		return jsn;
	}
	//**********

	cmdSave2() { // вызывается из файл-шоу, когда upload всех файлов закончится
		for ( let fs in this.fileShow )
			if (this.fileShow[fs].run)
				return;   // upload не закончен

		for ( let fs in this.fileShow )
			if ( this.fileShow[fs].uploadError ) { // upload закончен с ошибкой
				this.waitSave = false;
				this.setState({spinner: false});
				return;
			}
		let jsn = this.getNewValues(true);
		if ( jsn ) {
			this.runXhrSave( '{' + jsn.slice(0, -1) + '}' );  //вызов функции для отправки на сервер
		}
		else { //нет новых или измененных полей
			if ( this.flagClose )
				return this.props.closeDoc(this, this.tidy); // закрыть с поверкой автоордера

			this.waitSave = false;
			this.setState({spinner: false});

			this.cmdPrn(); // print if flagPrint == true
		}
	}
	//**********

	handleKeyDown(event) {
		if (	this.waitSave ||
				this.rsMode === 'preview' ||
				this.msg.state.isOpen ||
				this.dlg.state.isOpen ||
				this.dlgPreview.state.isOpen ||
				this.getField('_page_') ||
				( this.getField('form') === 'arm' && this.rsMode !== 'edit') )
			return;

		switch (event.keyCode) {
			case 49:	//alt-1
				if (event.altKey) {
					this.docSN();
					break;
				}
				return;
			case 83:	// Ctrl-s: save - no close
				if ( !this.state.readOnly && event.ctrlKey ) {
					this.cmdSave(false);
					break;
				}
				return;
			case 27:
				this.closeDoc(event.shiftKey);	//shift-esc - закрыть после сохранения
				break;
			case 80:
				if (event.ctrlKey) {
					this.cmdSave(null, true); // Ctrl-P: print флаг true - ПЕЧАТЬ после сохранения
					break;
				}
				return;
			case 13:
				if (event.ctrlKey && this.rsMode !== 'edit') {
					this.cmdEdit(); // Ctrl-enter: edit
					break;
				}
				return;
			default:
				return;
		}
		event.stopPropagation();
		event.preventDefault();
	}
	//**********

	closeDoc(force) {
		if ( this.state.readOnly || !this.dbAlias )
			return this.props.closeDoc(this, true); // close

		if ( force )	 //shift-esc
			return this.cmdSave(true);

		let jsn = this.getNewValues(false); // false - получить список несохраненных

		if ( !jsn )
			return this.props.closeDoc(this, this.tidy);

		this.msg.box(
				'Сохранить изменения ?',
				'Документ был изменен',
				['Сохранить+|Y', 'Нет|N', 'Изменения|S', 'Отмена'],
			)
			.then ( res => {
				if (res === 'Y')
					this.cmdSave(true);
				else if (res === 'N')
					this.props.closeDoc(this, true);
				else if (res === 'S')
					this.dlg.showFields(jsn)
						.then ( res => {
							if (res === 'Y')
								this.cmdSave(true);
							else if (res === 'N')
								this.props.closeDoc(this, true);
						})
						.catch( _ => this.setFocus(this.focus));
			})
			.catch( _ => this.setFocus(this.focus));
	}
	//**********

	addFiles(event) {
		if ( !this.state.readOnly ) {
			for ( let fs in this.fileShow ) {
				if ( !this.fileShow[fs].props.readOnly ) {
					this.fileShow[fs].addFiles(event);
					break;
				}
			}
		}
		event.stopPropagation();
		event.preventDefault();
	}
	//**********

	render() {
		if ( this.waitLoad ) {
			return this.state.spinner ? spinner(true, false) : null;
//			return this.state.spinner ? <div className="spinner-wrap"><div className="spinner"/></div> : null;
		}
		if ( ! this.children )
			return <div><h2>Ошибка при открытии документа</h2><h3>{'Пустая страница: ' + this.props.urlForm}<br/>{this.errMsg}<br/>{this.dbAlias + '&' + this.unid}</h3></div>;

		this.focusRows = [];
		this.currRow = 0;

		let ls = boxing(this.children, this, this.state.readOnly, false, this.pageAttr.wl);
		// ls[0] - массив меток-полей-кнопок в одной строке, ls[1] style строки, ls[2] className строки

		let pages = null;
		if ( this.mainDoc ) {
			pages = Object.keys(window.sovaPages).map( (key, i) => {
				let p = window.sovaPages[key];
				return key !== 'main' && p ?
					<div className="pageFrame" key={key + i} tabIndex="1" style={{...p.props.frameStyle, zIndex: this.zIndex === key ? 999 : (i+10), backgroundColor: this.dragStart === key ? 'rgba(0,0,0, 0.2)' : '#fff'}}>
						<div className="dlgTitleBar"  style={{cursor: 'move'}}
							onMouseDown={ e => { this.x1 = e.screenX; this.y1 = e.screenY; this.dragStart = this.zIndex = key;} }
						>
							{p.props.title || 'Multi-page'}
							<div className="dlgCloseButton" title="Закрыть" onClick={ _ => this.closePage(key)} >&times;</div>
							<div className="dlgMaxButton" title="Открыть в новой вкладке" onClick={ _ => this.maxPage(key)} >&#9650;</div>
						</div>
						<div style={{display: this.dragStart === key ? 'none' : 'block', width: '100%', position: 'realtive'}}>
							<Document {...p.props} closeDoc={ _ => this.closePage(key)} ref={o => p.doc = o}/>
						</div>
					</div>
					:
					null;
			});
		}

		let svText = this.readOnly || !this.savedText ?
			null
			:
			<div className="saved" style={{color: this.state.saved ? '#fff' : '#ddf'}}>{this.savedText}</div>;

		return (
			<div className={this.className} style={{ position: 'relative', ...this.style }}
				tabIndex="1"
				onKeyDown={this.handleKeyDown}
				onDragOver={(e) => { e.stopPropagation(); e.preventDefault(); }}
				onDrop={(e) => { e.stopPropagation(); e.preventDefault(); }}
				onMouseMove={this.dragPage}
				onMouseUp={this.pageMouseUp}
				ref={o => {if (o) { this.width = o.offsetWidth; this.height = o.offsetHeight; }} }
			>
				{ this.rsMode === 'edit' ? <audio ref={o => this.audiotuk = o} style={{display: 'none'}} src="/image?tuk.wav" /> : null }
				<MsgBox    doc={this} ref={ o => this.msg = o } />
				<DialogBox doc={this} ref={ o => this.dlg = o } />
				<DialogBox doc={this} ref={ o => this.dlgPreview = o } />
				{this.waitSave && this.state.spinner ? spinner(true, false) : null}
				{svText}
				<div
					style={{ position: 'relative', ...ls[1] }}
					className={ls[2]}
					onDrop={this.addFiles}
				>
					{ls[0]}
				</div>
				{pages}
			</div>
		);
	}
	//**********

	runXhrSave(data, force) {
		this.viewRefresh = true;
		let url = '/saveDoc?' + this.dbAlias + '&' + (force || '');

		fetch(url, { method: 'post', body: data, credentials: 'include' } )
			.then ( response => {
				this.waitSave = false;
				if ( response.status === 409 ) { // коллизия
					this.setState({spinner: false});
					response.text()	// тоже промис
						.then ( text => this.msg.box( 'ПЕРЕЗАПИСАТЬ ДОКУМЕНТ?\n' + text, 'Конфликт при сохранении', ['Да+|Y', 'Нет'] )
							.then ( _ => {
								this.waitSave = true;
								setTimeout(() => { if (this.waitSave) this.setState({spinner: true}); }, 500 );
								this.runXhrSave(data, 'force');
							})
							.catch ( _ => { this.flagClose = false; } )
						)
						.catch ( _ => alert('Конфликт при сохранении') );
				}
				else if ( response.status === 449 ) { // Проверка значений
					this.setState({spinner: false});
					response.text()	// тоже промис
						.then ( text => this.msg.box( text + '\n\nСОХРАНИТЬ?', 'Проверка значений при сохранении', ['Да+|Y', 'Нет'] )
							.then ( _ => {
								this.waitSave = true;
								setTimeout(() => { if (this.waitSave) this.setState({spinner: true}); }, 500 );
								this.runXhrSave(data, 'force');
							})
							.catch ( _ => { this.flagClose = false; } )
						)
						.catch ( _ => alert('Проверка значений') );
				}
				else {
					if ( response.status !== 200 ) {
						this.flagClose = false;
						this.setState({spinner: false});
						this.msg.error(`DocSave-status ${response.status}\n${response.statusText}\n\n${url}`);
					}
					else {	// УСПЕШНОЕ ОКОНЧАНИЕ СОХРАНЕНИЯ
						if ( this.flagClose ) {
							this.waitSave = false;
							this.setState({spinner: false});
							setTimeout( _ => this.props.closeDoc(this, false), 100);
						}
						else { // пересчитать документ с сервера
							Util.jsonByUrl(this.loadDocUrl())
								.then( jsn => {
									this.setDocProps(jsn);
									for ( let fs in this.fileShow )		// повторная инициализация
										this.fileShow[fs].initialize();
									Object.keys(this.fieldValues).forEach( xName => { // повторная инициализация после пересчитывания данных с сервера
										if ( xName in this.register && this.register[xName].setValue )
											this.register[xName].setValue(this.fieldValues[xName].replace(/¤/g, '\n'));
									});
									this.hideNewValues = {};
									this.savedText = 'Saved '+ Util.partition(Util.formatDateTime(new Date()), ' ')[1];
									this.setState({spinner: false, saved: true});
									setTimeout( _ => this.setState({saved: false}), 2000 );
									this.cmdPrn(); // print if flagPrint == true
									Util.runCmd(this, 'saved');
								})
								.catch ( error => {
									this.waitSave = false;
									this.setState({spinner: false});
									this.msg.error('DocSave-reload-error:' + error.message + '\n\nurl:' + url);
								});
						}
					}
				}
			})
			.catch ( error => {
				this.flagClose = false;
				this.waitSave = false;
				this.setState({spinner: false});
				this.msg.error('DocSave-error:' + (error.message || error) + '\n\nurl:' + url);
			});
	}
	//**********
}

export default Document
