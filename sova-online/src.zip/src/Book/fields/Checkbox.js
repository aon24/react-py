import React from 'react';
import autoBind from 'react-autobind';
import Util from '../common/Util';

export class Checkbox extends React.Component {
    constructor(props) {
        super(props);
        autoBind(this);
		this.state = { isChecked : !!this.props.xValue };
    }
	// *** *** ***

	getValue = _ => this.state.isChecked ? '1' : '';
	setValue = value => {
		this.setState( {isChecked : !!value} );
		Util.recalc(this, !!value);
	}
	//*** *** ***

	onchange = _ => {
		Util.recalc(this, !this.state.isChecked);
		this.setState( {isChecked : !this.state.isChecked} );
	}

    render() {
		return this.props.classic ?
		<div className={this.props.className} style={{...this.props.style}} title={this.props.title}>
			<input style={{cursor: 'pointer'}}
				type="checkbox"
				id={this.props.xName}
				checked={this.state.isChecked}
				disabled={this.props.readOnly}
				onChange={this.onchange}
			/>
			<label htmlFor={this.props.xName} style={{cursor: 'pointer'}}>
				{this.props.ls || ''}
			</label>
		</div>
		:
		<div className={this.props.className} style={{textAlign: 'left', ...this.props.style}} title={this.props.title}>
			<input type="checkbox"
				className=" checkbox"
				id={this.props.xName}
				checked={this.state.isChecked}
				disabled={this.props.readOnly}
				onChange={ () => {
						Util.recalc(this, !this.state.isChecked);
						this.setState( {isChecked : !this.state.isChecked} );
					}
				}
			/>
			<label htmlFor={this.props.xName}>{this.props.ls || ''}</label>
		</div>;
	}
	// *** *** ***
}

// *** *** ***
// *** *** ***

export class Checkbox3 extends React.Component {
    constructor(props) {
        super(props);
        autoBind(this);
		let value = 0;
		try {
			[this.labL, this.valL] = Util.partition(this.props.ls[0], '|');
			[this.labR, this.valR] = Util.partition(this.props.ls[1], '|');
			this.valL = this.valL || this.labL;
			this.valR = this.valR || this.labR;
			if (this.props.xValue === this.valL)
				value = -1;
			else if (this.props.xValue === this.valR)
				value = 1;
		}
		catch(ex) {
			this.labL = this.valL = -1;
			this.labR = this.valR = 1;
		}
		this.state = { value : value };
    }
	// *** *** ***

	getValue = _ => this.state.value < 0 ? this.valL : this.state.value ? this.valR : '';

	setValue = value => {
		let v = value === this.valL ? -1 : value === this.valR ? 1 : 0;
		this.setState( {value : v} );
		Util.recalc(this, this.getValue());
	}
	// *** *** ***

	render() {
		let cl = this.state.value < 0 ? 'chb3a' : 'chb3b';
		let cr = this.state.value > 0 ? 'chb3a' : 'chb3b';
		let cc = this.state.value ? 'chb3bc' : 'chb3ac';
		return (
			<div className={this.props.className || 'chb3'} style={{...this.props.style}} title={this.props.title}>
				<div onClick={_ => {Util.recalc(this, this.valL); this.setState({value: -1})}}>
					<div className={cl} style={{textAlign: 'right'}}>{this.labL+'\u00a0'}<div style={{float: 'right'}}>|</div></div>
				</div>
				<div style={{width: 20}} onClick={this.setEmpty}>
					<div className={cc}>{'\u00a0'}</div>
				</div>
				<div onClick={_ => {Util.recalc(this, this.valR); this.setState({value: 1})}}>
					<div className={cr} style={{textAlign: 'left'}}><div style={{float: 'left'}}>|</div>{'\u00a0'+this.labR}</div>
				</div>
			</div>);
	}

	setEmpty = _ => {
		if ( !this.props.noEmpty ) {
	 		Util.recalc(this, '');
			this.setState({value: 0})
		}
	};
    // *** *** ***
}
