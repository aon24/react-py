import React from 'react';
import autoBind from 'react-autobind';

import Text from './Text';
import Calendar from './Calendar';
import Util from '../common/Util';

class Datepicker extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.state = {
            focusOn: false,
			calendar: false,
		};
		this.m1 = this.props.m1;
		this.iniDP(this.props.xValue);
	}
	//**********

	setValue = (value, m1) => {
		this.m1 = m1;
		this.iniDP(value);
		this.forceUpdate();
	};
	getValue = rus => rus ?
		(this.dd ? this.dd + '.' + this.mm + '.' + this.styy + this.yy: '')
		:
		(this.dd ? this.styy + this.yy + '-' + this.mm + '-' + this.dd : '');
	setFocus = _ => { this.setState( {focusOn: true}); this.dde.focus(); }

	//**********

	iniDP(val) {
		if ( val ) {
			if ( typeof val === 'string' )
				this.setDate(val);
			else {
				let s = val.getUTCFullYear() + '-';
				let i = val.getUTCMonth() + 1;
				s += ( i < 10 ? '0' + i : i ) + '-';
				i = val.getUTCDate();
				s += ( i < 10 ? '0' + i : i ) + '-';
				this.setDate(s);
			}
		}
		else {
			this.dd = '';
			this.mm = '';
			this.yy = '';
			this.styy = '20';
		}
		this.waitDigit = 0;
		this.oneDigit = false;
	}
	//**********

	setDate(dat, e=null) {
		if ( e ) {
			e.stopPropagation();
			e.preventDefault();
		}

		let valid = false;
		if ( dat ) {
			let dd, mm, yy, styy;
	        try {
	            let da = dat.trim();
	            if ( da.slice(2, 3) === '.' ) {
	                dd   = da.slice(0, 2);
	                mm   = da.slice(3, 5);
	                yy   = da.slice(8, 10);
	                styy = da.slice(6, 8);
	            }
	            else if ( da.slice(4, 5) === '-' ) {
	                dd   = da.slice(8, 10);
	                mm   = da.slice(5, 7);
	                yy   = da.slice(2, 4);
	                styy = da.slice(0, 2);
	            }
	            else {
					if ( this.state.calendar ) {
						this.setState({calendar: false});
						this.yye.focus();
					}
	                return false;
				}
	            let d = new Date( parseInt(styy + yy, 10), parseInt(mm, 10) - 1, parseInt(dd, 10) );
	            valid = d.getMonth() === (parseInt(mm, 10)-1) && d.getDate() === parseInt(dd, 10) && d.getFullYear() === parseInt(styy+yy, 10)
				if ( valid ) {
					this.dd = dd;
					this.mm = mm;
					this.yy = yy;
					this.styy = styy;
				}
	        }
	        catch(ex) {}
		}
		else {
			valid = true;
		}
		if ( this.state.calendar ) {
			this.setState({calendar: false});
			this.yye.focus();
		}
		return valid;
	}
	//*********************************

	checkDT(e=null) {
		let valid = true;
		if( !this.dd) {
			this.mm = '';
			this.yy = '';
		}
		else {
			let nowD = new Date();
			if( !this.mm )
				this.mm = ('0' + (nowD.getMonth()+1).toString()).slice(-2);
			if( !this.yy ) {
				this.yy = nowD.getFullYear().toString().slice(-2);
				this.styy = '20';
			}

			let d = new Date(this.styy + this.yy, parseInt(this.mm, 10)-1, this.dd);
			valid = d.getMonth() === (parseInt(this.mm, 10)-1) && d.getDate() === parseInt(this.dd, 10);
		}

		if ( !valid )
			this.audioTuk();
		if ( e ) {
			e.stopPropagation();
			e.preventDefault();
		}
		this.forceUpdate();
		return valid;
	}
	//*********************************

	dtpFocus(e) {
		e.stopPropagation();
		e.preventDefault();
		this.setState({focusOn: true});
		let el = e.target;
		setTimeout(() => { el.selectionStart = 0}, 10);
		setTimeout(() => { el.selectionEnd = 0}, 10);
		this.waitDigit = 0;
		this.oneDigit = false;
	}

	dtpBlur(e) {
		this.setState({focusOn: false});
		if ( ! (this.checkDT(e) || this.state.calendar) ) {
			let oldFocus = e.target;
			setTimeout(() => { !this.state.focusOn && oldFocus.focus() }, 50);
		}
	}

	dtpPaste(e) {
	    try {
	        if ( !this.setDate(e.clipboardData.getData('text/plain')) )
	            this.audioTuk();
	    }
	    catch (ex) { this.audioTuk(); }

		this.checkDT(e);
	}
	//*********************************

	audioTuk() {
		if ( this.oneDigit )
			return;

		this.setState({red: true});
		setTimeout(() => {this.setState({red: false});}, 500);

		if (this.props.doc.audiotuk) {
			this.props.doc.audiotuk.pause();
			this.props.doc.audiotuk.currentTime = 0;
			this.props.doc.audiotuk.play();
		}
	}
	//*********************************

	toField(el, dir=true) {
		if ( dir ) {
			if ( el === this.dde )
				this.mme.focus();
			else if ( el === this.mme )
				this.yye.focus();
		}
		else {
			if ( el === this.yye )
				this.mme.focus();
			else if ( el === this.mme )
				this.dde.focus();
		}
	}
	//*********************************

	dtpKeyDown(e) {

		let c = e.keyCode;

		if( e.ctrlKey || (e.altKey && c !== 40) ) {
			if ( !this.checkDT() ) {
				e.stopPropagation();
				e.preventDefault();
			}
			return;
		}


		let upDowm = Util.upDown(e);
		if ( upDowm === 'up' )
			return this.props.doc.setFocus(this.props.myRow - 1);
		else if ( upDowm === 'down' )
			return this.props.doc.setFocus(this.props.myRow + 1);


		if(c >= 96 && c <= 105)
			return this.kbIsDigit(c-48, e);
		if(c >= 48 && c <= 57)
			return e.altKey ? this.checkDT(e): this.kbIsDigit(c, e);

		this.waitDigit = 0;

	    if ( c === 40 || c === 13 ) { // стрелка вниз, Enter
	        this.checkDT(e);
			return this.setState({calendar: true});
		}

		switch(c) {

		case 8:	// backspace
		case 46:	// del
			if(e.target === this.dde) {
                this.dd = '';
				return this.checkDT(e);
			}
			break;

		case 229: // пробел на андройде
		case 32:
			if(e.target === this.dde) {
				this.dd = ('0' + (new Date()).getDate().toString()).slice(-2);
				this.mm = '';
				this.yy = '';
				return this.checkDT(e);
			}
			break;

		case 110:	// "." or "/"
		case 111:
		case 190:
		case 191:
			if(this.oneDigit)
				this.toField(e.target);
			break;

		case 37: // <-
			if(e.target !== this.dde)
				this.toField(e.target, false);
			break;

		case 39: // ->
			if(e.target !== this.yye)
				this.toField(e.target);
			break;

		case 9:	// tab
			if ( this.checkDT() )
				return;
			break;
		case 27:
			if ( this.checkDT() )
				return;
			break;

		case 86: // ctrl-V
			if (e.ctrlKey)
				return;
            break;

	    case 45: //shift-Insert
			if(e.shiftKey)
				return;
            break;

	    default:
        	break;
		}
		e.stopPropagation();
		e.preventDefault();
	}
	//*********************************

	kbIsDigit(c, e) {
		let el = e.target;

		if ( !this.dd && el !== this.dde )
			return this.checkDT(e);

		let ic = String.fromCharCode(c);

		if(el === this.yye) {
			if (this.waitDigit === 0) {
				this.waitDigit = 1;
				this.yy = '0' + ic;
				setTimeout(() => {if(this.waitDigit === 1) this.waitDigit = 0;}, 1000);
			}
			else if (this.waitDigit === 1) {
				this.waitDigit = 2;
				this.yy = this.yy[1] + ic;
				setTimeout(() => {if(this.waitDigit === 2) this.waitDigit = 0;}, 1000);
			}
			else if (this.waitDigit === 2) {
				this.waitDigit = 3;
				this.styy = this.yy;
				this.yy = '0' + ic;
				setTimeout(() => {this.waitDigit = 0;}, 1000);
			}
			else if (this.waitDigit === 3) {
				this.yy = this.yy[1] + ic;
				this.waitDigit = 0;
				//setTimeout('waitDigit = 0;', 1000);
			}
			return this.checkDT(e);
		}

		let max1, max2, val;
		let iic = parseInt(ic, 10);
		if ( el === this.dde ) {
			max1 = 3;
			max2 = 31;
			val = this.dd;
		}
		else {
			max1 = 1;
			max2 = 12;
			val = this.mm;
		}

		if ( this.waitDigit ) { // ожидание второй цифры
			let nn = parseInt(val, 10)*10 + iic;
			if (nn === 0 || nn > max2)
                this.audioTuk();
			else {
				if ( el === this.dde )
					this.dd = (nn > 9 ? '' : '0') + nn.toString();
				else
					this.mm = (nn > 9 ? '' : '0') + nn.toString();
				this.toField(el);
			}
		}
		else {
			this.oneDigit = true;
			if ( el === this.dde )
				this.dd = '0' + ic;
			else
				this.mm = '0' + ic;
			if( iic > max1 ) {
				this.toField(el);
			}
			else {
				this.waitDigit = 11;
				setTimeout(() => {if(this.waitDigit === 11) this.waitDigit = 0;}, 1000);
			}
		}
		this.checkDT(e);
	}
	//*********************************

	//*********************************
	render() {
		let p = {
			className: 'dd',
			autoComplete: 'off',
			type: 'text',
			onFocus: this.dtpFocus,
			onBlur: this.dtpBlur,
			onPaste: this.dtpPaste,
			onKeyDown: this.dtpKeyDown,
			onChange: () => {},
		};
//		let borderColor = this.state.red ? 'red' : this.state.calendar ? '#00ff00' : 'transparent';
		let bgr = this.state.red ? '#FFA07A' : this.state.calendar ? '#A0FF7A' : this.state.focusOn ? '#f4fdff' : 'white';

		let calendar = null;
		if ( this.state.calendar ) {
			let rect = this.calendarDiv.getBoundingClientRect();
			let y = Math.round(rect.top);
			let x = Math.round(rect.left);
			let wh = window.innerHeight;
			let ww = window.innerWidth;

			y = ((wh - y) > 255) ? (y + 23) : Math.max(y - 225, 5);
			x = this.m1 || Util.anyMobile ?
				x - 40
				:
				(x < 280) ? 10 : ((ww - x) > 345 ? x - 225 : Math.max(ww - 575, 10));

			calendar =
			<Calendar
				dayX={this.props.dayX}
				m1={this.m1}
				leftTop={{marginLeft: x, marginTop: y}}
				setDate={ (s, e) => this.setDate(s, e) }
				cur={this.dd && this.mm && this.yy ? new Date(parseInt(this.styy+this.yy, 10), parseInt(this.mm, 10)-1, parseInt(this.dd, 10)) : new Date()}
			/>;
		}
		return this.props.readOnly ?
		<Text xValue={this.getValue(true)} readOnly={true} style={{ ...this.props.style}}/>
			:
		<div style={{ ...this.props.style}}>
			<div className={ 'tta' + (this.state.focusOn ? ' on-focus' : '')} style={{ ...this.props.style, background: bgr}}>
				<div
					className="datePicker"
					title="Для вызова календаря нажмите 'стрелку-вниз' на клавиатуре или пиктограмму мышкой"
					ref={ o => this.calendarDiv = o }
					style={{width: '3.1cm'}}
				>
					<input
						tabIndex="0"
						{...p}
						placeholder="дд"
						value={this.dd}
						ref={ o => this.dde = o }
					/>
					<span
						onClick={ () => this.dde && this.dde.focus() }
					>.</span>
					<input
						tabIndex={-1}
						{...p}
						placeholder="мм"
						value={this.mm}
						ref={ o => this.mme = o }
					/>
					<span
						onClick={ () => this.mme && this.mme.focus() }
					>.</span>
					<span
						onClick={ () => this.yye && this.yye.focus() }
						className="styy"
						style={ this.yy ? {color: 'black'} : {}}
					>{this.styy}</span>
					<input
						tabIndex={-1}
						{...p}
						placeholder="гг"
						value={this.yy}
						ref={ o => this.yye = o }
					/>
					<span
						onClick={ () => this.yye && this.yye.focus() }
					>&nbsp;</span>
					<div
						className="dtp"
						onClick={ () => this.setState({calendar: true}) }>
						<div className="dtp1"></div>
						<div className="dtp2">{('0' + (new Date()).getDate().toString()).slice(-2)}</div>
					</div>
					{calendar}
				</div>
			</div>
		</div>;
	}
	//**********
}

export default Datepicker;
