import React from 'react';
import autoBind from 'react-autobind';

import Text from './Text';
import Util from '../common/Util';

class ListBox extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.multi = this.props.type === 'lbmd';
		this.placeholder = 'Выберите значение из списка';
		this.inputEnable = true;
		this.input = '';
		this.sep = this.props.sep || '|';

		this.state = {
			value: this.props.xValue || '',
			focusOn: false,
		};
	}
	//**********

	setValue = value => this.setV(value);
	getValue = _ => this.state.value;
	setFocus = _ => { this.setState( {focusOn: true}); this.tta.focus(); }

	setV(val) {
		this.inputEnable = true;
		this.input = '';
		this.setState( {value: val || ''} );
	}
	//**********

	componentDidMount = _ => this.changeDropList();

	changeDropList(newList) {
		let ls = this.props.ls;
		if ( this.props.readOnly || !ls || !ls.length )
			return this.setState ({ dropList: [] });

		if ( typeof ls === 'string' ) { // строка - url
			if ( ls.includes('|||') ) {
				let [fi, t] = ls.split('|||');
				ls = t.replace(/{FIELD}/g, newList || this.props.doc.getField(fi));
			}
			Util.jsonByUrl(ls)
				.then( jsn => {
					this.labels = (jsn || []).map( it => it.split(this.sep)[0].toLowerCase() );
					this.values = this.props.alias && (jsn || []).map( it => Util.partition(it, this.sep)[1] ); //если алиас=1, по пробелу надо искать не только в метках, но и в значениях, т.к. в поле переноситсся не метка, а значение
					this.setState ({ value: this.state.value || '', dropList: jsn || [] })
				})
				.catch ( mess => console.error('ListBoxSD.js: Util.jsonByUrl:' + mess) );
		}
		else {
			let nl = newList || ls;
			this.labels = nl.map( it => it.split(this.sep)[0].toLowerCase() );
			this.values = this.props.alias && nl.map( it => Util.partition(it, this.sep)[1] ); //если алиас=1, по пробелу надо искать не только в метках, но и в значениях, т.к. в поле переноситсся не метка, а значение
			this.setState ( { value: this.state.value || '', dropList: nl } );
		}
	}
	//**********

	onkeydown(e) {
		let upDowm = Util.upDown(e);
		if ( upDowm === 'up' )
			return this.props.doc.setFocus(this.props.myRow - 1);
		else if ( upDowm === 'down' )
			return this.props.doc.setFocus(this.props.myRow + 1);


		let i = 0;
		switch(e.keyCode) {
			case 37:
			case 39: this.input = '';
					 this.inputEnable = !this.state.value;
					 this.forceUpdate();
					 break;
			case 13: return this.showListBox (e);
			case 40:
				return e.altKey ? this.showListBox (e) : true;
			case 8:		// backspace
				return this.delValue(e, -1);
			case 46:	// del
				return this.delValue(e, 0);
			case 32:
				let newVls = [];
				if ( this.state.value ) {
					let vls = this.state.value.split('\n'); //_
					newVls = vls.slice(0, -1); // newVls все значения, кроме последнего, т.к. последнее надо заменить
					i = this.labels.indexOf(vls.slice(-1)[0].split(this.sep)[0].toLowerCase()); // найти в метках последнее введенное значение поля

					if ( i >= 0 && i < this.labels.length-1 )
						i += 1;
					else {
						if ( this.props.alias)  // если в метках не нашел, искать в значениях т.к. для алиас=1 в поле заносится не метка, а значение
							i = this.values.indexOf(vls.slice(-1)[0].split(this.sep)[0]);
						if ( i >= 0 && i < this.labels.length-1 )
							i += 1;
						else
							i = 0;
					}
				}
				newVls.push(this.state.dropList[i]);
				this.updateValue(newVls.join('\n')); //_
				break;
			default:
				return;
		}
		e.stopPropagation();
		e.preventDefault();
	}
    //**********

	onkeypress(e) {
		if (e.ctrlKey)
			return;

		let key = e.key.toLowerCase();
		if ( ! this.inputEnable )
			return this.showListBox(e, key);

		e.stopPropagation();
		for ( let j in this.labels )
			if ( this.labels[j].startsWith(this.input + key) ) {
				this.input += key;
				this.updateValue(this.state.dropList[j], false);
				return;
			}
		let sep = '(«"\'-';
		for ( let ch of sep ) {
			let tx = ch + this.input + key;
			for ( let j in this.labels )
				if ( this.labels[j].includes(tx) ) {
					this.input += key;
					this.updateValue(this.state.dropList[j], false);
					return;
				}
		}
	}
	//**********

	onpaste(e) {
	    try {
	        let tx = e.clipboardData.getData('text/plain').toLowerCase();
			if ( ! this.inputEnable )
				this.showListBox(e, tx);
			else {
				this.input = '';
				let i = 0, j;
				for ( let x in tx ) {
					let flag = false;
					for ( ; i < this.labels.length; i++ ) {
						if ( this.labels[i].startsWith(this.input + tx[x]) ) {
							flag = true;
							break;
						}
					}
					if (flag) {
						j = i;
						this.input += tx[x];
					}
					else
						break;
				}
				this.input && this.updateValue(this.state.dropList[j], false);
			}
	    }
	    catch (ex) {
			console.error('Ошибка при вставке текса:' + ex.message);
		}
		e.stopPropagation();
		e.preventDefault();
	}
	//**********

	showListBox(event, text=null) {
		event.stopPropagation();
		event.preventDefault();
		if ( !(this.state.dropList && this.state.dropList.length)  )
			return;

		let dropL2 = this.state.dropList.map( it => it.split(this.sep)[0] );
		let checked = this.input || text || (!this.state.value) ?
			0
			:
			this.state.value.split('\n') //_
				.reduce ( (arr, it) => { // отфильтровать из droplist уже выбранные и передать в msg.list их индексы
					let val = it.split(this.sep)[0];
					let i = dropL2.indexOf(val);
					if ( i >= 0 )
						arr.push(i);
					else if ( this.props.alias ) { // если props.alias=1, то в поле занесется не label, а то, что справа от |, т.е. значение
						i = this.values.indexOf(val);
						if ( i >= 0 )
							arr.push(i);
					}
					return arr;
				}, [] );
		this.props.doc.msg.list ( this.state.dropList,
				'Выберите значение',
				{ multi: this.multi && !text, checked: checked, text: this.input || text, sep: this.sep }, this.props.small )
			.then( res => {
				this.updateValue(res, true, !!text && this.multi);
				this.tta.focus();
			})
			.catch( _ => this.tta.focus() );
	}
	//**********

	findAlias(newValue) {
		let val = [];
		let als = [];

		newValue.split('\n').forEach( it => { //_
			let [left, right] = Util.partition(it, this.sep);

			if ( this.props.alias )
				val.push( right ? right : left );
			else {
				val.push(left);
				als.push(right);
			}
		});

		return [val.join('\n'), als.join('\n')]; //_
	}
	//**********

	updateValue (newValue, clearInput=true, saveOldValue=false) {
		// TODO: сделать проверку на уникальность значений

		if ( clearInput )
			this.input = '';
		this.inputEnable = !(newValue && clearInput); // сбрасывается после 1-й буквы, кроме случая, когда ввод в пустое поле

		let [value, alias] = this.findAlias(newValue);
		this.setState({value: (saveOldValue && this.state.value ? this.state.value + '\n' : '') + value}); //_
		if ( this.props.saveAlias ) {
			if ( saveOldValue ) {
				let oldAlias = this.props.doc.getField(this.props.xName + '_ALIAS');
				alias = (oldAlias ? oldAlias + '\n' : '') + alias; //_
			}
			this.props.doc.setField(this.props.xName + '_ALIAS', alias);
		}
		Util.recalc(this, value, alias);
	}
	//**********

	delValue(event, index) { // удалить значение с номером "index"
		event.stopPropagation();
		event.preventDefault();
		let ls = this.state.value.split('\n'); //_
		if ( ls.length) {
			if ( index < 0 )
				index = ls.length - 1;

			let newAlias = '';
			if ( this.props.saveAlias ) {
				let lsa = this.props.doc.getField(this.props.xName + '_ALIAS').split('\n'); //_
				if ( ls.length === lsa.length ) {
					 newAlias = lsa.filter( (it, i) => i !== index ).join('\n'); //_
					 this.props.doc.setField(this.props.xName + '_ALIAS', newAlias);
				}
			}

			let newValue = ls.filter( (it, i) => i !== index ).join('\n') //_

			this.input = '';
			this.inputEnable = !newValue;

			this.setState({value: newValue});
			Util.recalc(this, newValue, newAlias);
		}
	}
	//**********

	render () {
		if ( this.props.readOnly )
			return <Text xValue={this.props.xValue || ''} readOnly={true} style={{...this.props.style}}/>;

		let cursor = this.state.focusOn && !this.input ? <span className="lbCursor">|</span> : null;

		let ls = this.state.value.split('\n').map( (it, i, array) => { //_
			if ( !it ) {
				let ph = this.props.readOnly || this.state.focusOn ? '\u00a0' : this.props.placeholder || this.placeholder;
				return (
					<div key={i} style={{border: '1px solid transparent'}}>
						<span className="placeholder">{ph}</span>{cursor}
					</div>);
			}
			let label = it.split(this.sep)[0];
			let selText = null;
			if ( this.input && label.toLowerCase().indexOf(this.input) === 0 ) {
				selText = <b style={{color: '#f08'}}>{label.slice(0, this.input.length)}</b>;
				label = label.slice(this.input.length);
			}
			return (
				<div key={i} style={{border: '1px solid #eee'}}>
					<span
						className="delBtn"
						title="Удалить"
						onClick={ event => this.delValue(event, i) }
					>
						&times;
					</span>
					{selText}{label}{ i < array.length-1 ? null : cursor }
				</div>);
		});
		return (
		<div style={{ ...this.props.style}}>
			<div
				className={ 'tta' + (this.state.focusOn ? ' on-focus' : '')}
				style={{padding: '2px 0 2px 2px', ...this.props.ttaStyle }}
				tabIndex={'0'}
				onFocus={ _ => { this.inputEnable = !this.state.value; this.setState({ focusOn: true }) } }
				onBlur={ _ =>  { this.inputEnable = false; this.input = ''; this.setState({ focusOn: false }) } }
				onKeyDown={this.onkeydown}
				onKeyPress={this.onkeypress}
				onPaste={this.onpaste}
				ref={o => this.tta = o}
			>
				<div style={{display: 'table-cell'}}>
					{ls}
				</div>
				<div
					className="btn-lb-zone"
					onClick={ e => this.showListBox(e) }
				>
					<div className="btn-lbsd"/>
				</div>
			</div>
		</div>);
	}
	//************
}

export default ListBox;
