import React from 'react';
import autoBind from 'react-autobind';

class SvFrame extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);
		this.state = {
			isLoading: true,
			src: this.props.src,
			srcDoc: this.props.srcDoc || (!this.props.src && '<html><body></body></html>'),
		};
		setTimeout( _ => this.state.isLoading ? this.setState({...this.state, spinner: true}) : '', 1000);
	}
	// *** *** ***

	setValue = (src, srcDoc) => this.setState({src: src, srcDoc: srcDoc});

	// *** *** ***

	render = _ => {
		let src = this.state.src;
		let srcDoc = null;

		if ( this.state.srcDoc ) {
			src = null;
			srcDoc = this.state.srcDoc;
		}
		else {
			if ( ['.jpg', '.jpeg', '.png', '.gif'].filter( it => src.toLowerCase().includes(it) ).length ) {
				srcDoc = `<html><body style="margin:0; text-align: center"><img src="${src}" width="100%" alt="alt"></body></html>`;
				src = null;
			}
		}

		return (
			<div style={{position: 'relative'}}>
				{ this.state.isLoading && this.state.spinner ? <div className="spinner"/> : null }
				<iframe
					name={this.props.name}
					id={this.props.id}
					ref={this.props.name || "iframe"}
					src={src}
					srcDoc={srcDoc}
					style={{...this.props.style}}
					title={this.props.title || 'Title'}
					onLoad={ _ => { this.props.load && this.props.load(this); this.setState({isLoading: false}); } }
				/>
			</div>
		);
	}
}
// *** *** ***

export default SvFrame
