import React from 'react';
import autoBind from 'react-autobind';
import {Util} from '../common/Util';

// *** *** ***

var idc = 0;
var moved = {};
var copyItem;

// *** *** ***

class Svg extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);
		try {
			this.oldSvg = JSON.parse(this.props.xValue);
		}
		catch(ex) {
			console.log('Svg.js.JSON.parse', this.props.xValue, typeof this.props.xValue);
			this.oldSvg = null;
			this.errBox = <div style={{color: 'red'}}>Ошибка в поле SVG<br/>{ex.name + ': ' + ex.message}</div>;
		}
		window.onkeydown = this.handleKeyDown;
	}
	// *** *** ***

	getValue = _ => this.equ(this.oldSvg, this.newBox) ?
		this.props.doc.fieldValues[this.props.xName]
		:
		JSON.stringify( this.svgBoxToField(this.newBox) );

	// *** *** ***

	svgBoxToField = box => {
		let el = {_teg: box.props._teg, attributes: {}, setting: {}};

		for( let it of ['id', 'x', 'y', 'w', 'h'] ) {
			if ( box[it] || box[it] === 0)
				el.attributes[it] = box[it].toString();
		}
		for( let it in box.setting ) {
			el.setting[it] = box.setting[it];
		}
		if (box.tree) {
			let children = [];
			box.tree.forEach( it => ( !it.state || !it.state.deleted) && children.push(this.svgBoxToField(it)) );
			if (children.length)
				el.children = children;
		}
		return el;
	};
	// *** *** ***

	equ(oldSvg, newBox) {
		if ( newBox.state && newBox.state.delete )
			return;
		if ( oldSvg.attributes.id !== newBox.id )
			return;
		if ( !Util.cmpObj(oldSvg.setting, newBox.setting) )
			return;
		for( let it of ['x', 'y', 'w', 'h'] ) {
			if (typeof newBox[it] === 'number') {
				if ( oldSvg.attributes[it] !== newBox[it].toString() )
					return;
			}
			else if (oldSvg.attributes[it]) // если не 'number', значит 'undefined'
				return;
		}
		if ( !!oldSvg.children !== !!newBox.tree )
			return;

		if ( newBox.tree ) {
			for ( let i = 0; i < newBox.tree.length; i++)
				if ( !this.equ(oldSvg.children[i], newBox.tree[i]) )
					return;
		}
		return true;
	}
	// *** *** ***

	handleKeyDown(event) {
		if (	this.props.doc.waitSave ||
				this.props.doc.rsMode === 'preview' ||
				this.props.doc.msg.state.isOpen ||
				this.props.doc.dlg.state.isOpen ||
				this.props.doc.dlgPreview.state.isOpen ||
				this.props.doc.getField('_page_') )
			return;

		switch (event.keyCode) {
			case 83:	// Ctrl-s: save - no close
				if ( !this.props.doc.state.readOnly && event.ctrlKey ) {
					this.props.doc.cmdSave(false);
					break;
				}
				return;
			case 27:
				this.props.doc.closeDoc(event.shiftKey);	//shift-esc - закрыть после сохранения
				break;
			case 80:
				if (event.ctrlKey) {
					this.props.doc.cmdSave(null, true); // Ctrl-P: print флаг true - ПЕЧАТЬ после сохранения
					break;
				}
				return;
			default:
				return;
		}
		event.stopPropagation();
		event.preventDefault();
	}
	// *** *** ***

	render = _ => this.oldSvg ?
		<SvgBox
			doc={this.props.doc}
			{...this.oldSvg.attributes}
			setting={this.oldSvg.setting}
			children={this.oldSvg.children}
			ref={o => {this.newBox = o}}
			style={this.props.style}
			onKeyDown={this.handleKeyDown}
			_teg="svgBox"
		/>
			:
		this.errBox;
}
// *** *** ***

class SvgBox extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.setting = {...this.props.setting};
		this.sendShow = this.props.sendShow;

	    this.r = 4;
	    this.rr = this.r + 1;
	    this.x = parseInt(this.props.x, 10) || 0;
	    this.y = parseInt(this.props.y, 10) || 0;
	    this.w = parseInt(this.props.w, 10) || 20;
	    this.h = parseInt(this.props.h, 10) || 20;

		this.svg = this;
		this.tree = [];
		if(this.props.tree)
			this.props.tree.push(this);

		if (this.props.svg) {
			idc++;
			this.id = 'box_' + idc;
			moved[this.id] = this;
			this.cursor = 'move';
			this.attrCirc = {
				r: this.r,
				fill: 'white',
				stroke: this.setting.type === 'div' ? 'blue' : 'green',
				strokeWidth: '1',
			};
		}
		else {
			this.props.doc.mainSvg = this;
			this.id = 'main';
			this.dom = React.createRef();
			this.mouse = {
				onMouseMove: e => this.mouseMove(e),
				onMouseDown: e => this.mouseDown(e),
				onMouseUp: e => this.mouseUp(e),
				onContextMenu: e => this.contextMenu(e),
			};
		}
		this.state = {svgBox: parseSvg(this, this.props.children)};
	}
	// *** *** ***

	appendChild = typeCh => {
		let url = `api.get?insertSvgItem&${this.props.doc.dbAlias}&${typeCh}`;
		let w = this.id === 'main' ? 400 : this.w > 40 ? this.w - 20 : 30;
		let h = this.id === 'main' ? 160 : this.h > 40 ? this.h - 20 : 30;
		Util.jsonByUrl(url)
			.then( jsn => {
				// let attr = {...jsn.attributes || {} };
				let box =
					<SvgBox
						key={Math.random()}
						id="box"
						svg={this}
						_teg="svgBox"
						x={7} y={7} w={w} h={h}
						setting={{...jsn.setting}}
						children={jsn.children}
						tree={this.tree}
						doc={this.props.doc}
						sendShow={true}
					/>;
				let b = (this.state.svgBox || []).slice();
				b.push(box);
				this.setState({svgBox: b});
			})
			.catch ( mess => console.error(`Svg.js.appendChild: Util.jsonByUrl(${url}):${mess}`) );
	};

	componentDidMount = _ => {
		this.sendShow && Util.runCmd(this.props.doc, 'sendShow');
		this.sendShow = false;
	}
	// *** *** ***

	contextMenu = e => {
		if ( e.target.id ) {
			let id = Util.partition(e.target.id, '__')[0];
			if (id === 'main' || id.startsWith('box_'))
				Util.runCmd(this.props.doc, 'contextMenu', {event: e, dom: this.dom.current, box: moved[id] || this});
		}
		e.preventDefault();
		e.stopPropagation();
	}

	mouseDown = e => {
		if ( e.target.id ) {
			if (this.props.doc.contextMenu) {
				this.props.doc.contextMenu = false;
				this.props.doc.forceUpdate();
			}
			else {
				this.ctm = this.dom.current.getScreenCTM();
				this.pt = this.dom.current.createSVGPoint();
				this.pt0 = this.dom.current.createSVGPoint();
			    this.pt0.x = e.clientX;
			    this.pt0.y = e.clientY;
				this.pt0 = this.pt0.matrixTransform(this.ctm.inverse());

				[this.clickedId, this.type] = Util.partition(e.target.id, '__'); // box_4__6 => elem: box_4, type 6
				this.type = this.type || Util.partition(this.clickedId, '_')[0]; // HL_2 => elem: HL_2, type HL
				this.current = moved[this.clickedId];
				this.owner = this.current && this.current.props.svg;
			}
		}
		else {
			this.clickedId = null;
			this.type = null;
		}
		e.preventDefault();
		e.stopPropagation();
	}
	// *** *** ***

	mouseMove(e) {
		if ( !(e.buttons === 1 && this.type && this.owner) )
			return;

	    this.pt.x = e.clientX;
	    this.pt.y = e.clientY;
	    this.pt = this.pt.matrixTransform(this.ctm.inverse());
		let deltaX = this.pt.x - this.pt0.x;
		let deltaY = this.pt.y - this.pt0.y;

		switch (this.type) {
			case 'HL':
				this.current.y += deltaY;
				this.current.forceUpdate();
				break;
			case 'VL':
				this.current.x += deltaX;
				this.current.forceUpdate();
				break;
			case 'R0':
				this.current.x += deltaX;
				this.current.y += deltaY;
				this.current.forceUpdate();
				break;
			case '1':
				this.current.w = Math.max(this.current.w - deltaX, 3);
				this.current.h = Math.max(this.current.h - deltaY, 3);
				this.current.x += deltaX;
				this.current.y += deltaY;
				this.current.forceUpdate();
				break;
			case '2':
				this.current.w = Math.max(this.current.w + deltaX, 3);
				this.current.h = Math.max(this.current.h - deltaY, 3);
				this.current.y += deltaY;
				this.current.forceUpdate();
				break;
			case '3':
				this.current.w = Math.max(this.current.w + deltaX, 3);
				this.current.h = Math.max(this.current.h + deltaY, 3);
				this.current.forceUpdate();
				break;
			case '4':
				this.current.w = Math.max(this.current.w - deltaX, 3);
				this.current.h = Math.max(this.current.h + deltaY, 3);
				this.current.x += deltaX;
				this.current.forceUpdate();
				break;
			case '5':
				this.current.h = Math.max(this.current.h - deltaY, 3);
				this.current.y += deltaY;
				this.current.forceUpdate();
				break;
			case '6':
				this.current.w = Math.max(this.current.w + deltaX, 3);
				this.current.forceUpdate();
				break;
			case '7':
				this.current.h = Math.max(this.current.h + deltaY, 3);
				this.current.forceUpdate();
				break;
			case '8':
				this.current.w = Math.max(this.current.w - deltaX, 3);
				this.current.x += deltaX;
				this.current.forceUpdate();
				break;
			default:
		}
		this.pt0.x = this.pt.x;
		this.pt0.y = this.pt.y;
		this.forceUpdate();
		e.preventDefault();
		e.stopPropagation();
	}

	mouseUp(e) {
		this.type = null;
		this.forceUpdate();
		e.preventDefault();
		e.stopPropagation();
		Util.runCmd(this.props.doc, 'sendShow');
	}
	// *** *** ***
	setProprty = _ => window.setSvgBoxProprty(this.props.doc, this);

	render = _ => {
		if (this.state.deleted)
			return null;

		if ( !this.props.svg )
			return (
				<svg x={0} y={0} style={{...this.props.style}} {...this.mouse} ref={this.dom} id={this.id}>
					<text cursor="pointer" onClick={this.setProprty} x="2" y="20" fill="#a40" fontSize="10pt" fontFamily="verdana" style={{background: '#def'}}>page</text>
					{this.state.svgBox}
			    	<circle id={this.id+'__P'} onClick={this.pasteItem} cx={15} cy={45} r={7} fill="#0f8" cursor="pointer"><title>paste item</title></circle>
				</svg>);

	    let w0 = this.w + (2*this.rr);
	    let h0 = this.h + (2*this.rr);
	    let x = this.x - this.rr;
	    let y = this.y - this.rr;
	    let w = this.w + this.rr;
	    let h = this.h + this.rr;
	    let x2 = this.w/2 + this.rr;
	    let y2 = this.h/2 + this.rr;

		let d = `M ${this.rr} ${this.rr} H ${w} V ${h} H ${this.rr} Z`;
		let stroke = this.setting.type === 'div' ? 'blue' : 'green';
		let idp = this.id + ': ' + this.setting.type;
		let text = this.setting.text ?
			<text cursor="pointer" onClick={this.setProprty} x="10" y="20" fill="#888" fontSize="10pt" fontFamily="verdana" style={{background: '#def'}}>
				{this.setting.text.substr(0, 80)}<title>property</title>
			</text>
			:
			null;

		return (
			<svg x={x} y={y} width={w0} height={h0} fill="rgba(255,255,255, 0.8)" cursor={this.cursor} {...this.mouse} id={this.id}>
			    <path id={this.id+'__R0'} d={d} stroke={stroke}/>
				{text}
				<text cursor="pointer" onClick={this.setProprty} x="10" y={h-5} fill="#a40" fontSize="10pt" fontFamily="verdana" style={{background: '#def'}}>
					{idp}<title>property</title>
				</text>
			    <circle id={this.id+'__1'} cx={this.rr} cy={this.rr} {...this.attrCirc} cursor="nwse-resize"/>
			    <circle id={this.id+'__2'} cx={w} cy={this.rr} {...this.attrCirc} cursor="nesw-resize"/>
			    <circle id={this.id+'__3'} cx={w} cy={h} {...this.attrCirc}  cursor="nwse-resize"/>
			    <circle id={this.id+'__4'} cx={this.rr} cy={h} {...this.attrCirc} cursor="nesw-resize"/>

			    <circle id={this.id+'__5'} cx={x2} cy={this.rr} {...this.attrCirc} cursor="n-resize"/>
			    <circle id={this.id+'__6'} cx={w} cy={y2} {...this.attrCirc} cursor="e-resize"/>
			    <circle id={this.id+'__7'} cx={x2} cy={h} {...this.attrCirc} cursor="n-resize"/>
			    <circle id={this.id+'__8'} cx={this.rr} cy={y2} {...this.attrCirc} cursor="e-resize"/>
			    <circle id={this.id+'__C'} onClick={_ => copyItem = this.id} cx={w-30} cy={h-10} r={7} fill="#08f" cursor="pointer"><title>copy item</title></circle>
			    <circle id={this.id+'__P'} onClick={this.pasteItem} cx={w-10} cy={h-10} r={7} fill="#0f8" cursor="pointer"><title>paste item</title></circle>
			    <circle id={this.id+'__D'} onClick={this.deleteItem} cx={w-10} cy={15} r={7} fill="#f80" cursor="pointer"><title>delete item</title></circle>
 <animate xlinkHref={'#'+this.id+'__C'} attributeName="r" from="7" to="50" dur="0.2s" begin="click" fill="freeze"/>
 <animate xlinkHref={'#'+this.id+'__C'} attributeName="r" from="50" to="7" dur="0.2s" begin="click+0.2s" fill="freeze"/>
 <animate xlinkHref={'#'+this.id+'__P'} attributeName="r" from="7" to="50" dur="0.2s" begin="click" fill="freeze"/>
 <animate xlinkHref={'#'+this.id+'__P'} attributeName="r" from="50" to="7" dur="0.2s" begin="click+0.2s" fill="freeze"/>
				{this.state.svgBox}
			</svg>
		);
	}
	// *** *** ***

	deleteItem = _ => {
		this.props.doc.msg.box(
				`Delete item "${this.id}" ?`,
				'Warning',
				['Delete+|Y', 'Cancel'],
			)
			.then ( res => {
				this.props.svg.tree.forEach( it => it===this && this.setState({deleted: true}) );
				setTimeout(_ => Util.runCmd(this.props.doc, 'sendShow'), 100);
			})
			.catch( _ => {});
	}

	pasteItem = _ => {
		if (!copyItem)
			return;

		if ( !(['div', 'form', 'span', 'b', 'i', 'p', 'ol', 'ul', 'a', 'label'].includes(this.setting.type) || this.id === 'main') )
			return this.props.doc.msg.box('You can paste an item in the div. Box: ' + this.setting.type, 'warning');

		let paste = moved[copyItem];
		let w = this.id === 'main' ? paste.w : Math.min(paste.w, this.w - 16);
		let h = this.id === 'main' ? paste.h : Math.min(paste.h, this.h - 16);
		let box =
			<SvgBox
				key={Math.random()}
				id="box"
				svg={this}
				_teg="svgBox"
				x={8} y={8} w={w} h={h}
				setting={{...paste.setting}}
				children={(paste.props.children || []).slice()}
				tree={this.tree}
				doc={this.props.doc}
				sendShow={true}
			/>;
		let b = (this.state.svgBox || []).slice();
		b.push(box);
		this.setState({svgBox: b});
	}
}
// *** *** ***

class SvgLine extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		idc++;
		this.x = parseInt(this.props.x || 0, 10);
		this.y = parseInt(this.props.y || 0, 10);
		if (this.y) { // HL
			this.id = 'HL_' + idc;
			this.x1 = 9;
			this.y1 = 2;
			this.x2 = 5000;
			this.y2 = 2;
			this.cursor = 'n-resize';
			this.w = 6000;
			this.h = 4;
		}
		else {
			this.id = 'VL_' + idc;
			this.x1 = 2;
			this.y1 = 9;
			this.x2 = 2;
			this.y2 = 6000;
			this.cursor = 'e-resize';
			this.w = 4;
			this.h = 6000;
		}
		this.props.tree.push(this);
		moved[this.id] = this;
	}
	// *** *** ***

	render = _ => {
		return (
		    <svg x={this.x} y={this.y} cursor={this.cursor}>
				<line strokeWidth={2} strokeDasharray={7} x1={2} y1={2} style={{stroke: '#ccc'}} x2={this.x2} y2={this.y2}/>
				<line strokeWidth={2} strokeDasharray={7} x1={this.x1} y1={this.y1} x2={this.x2} y2={this.y2} style={{stroke: '#777'}}/>
				<rect id={this.id} x={0} y={0} fill="transparent" width={this.w} height={this.h}/>
		    </svg>);
	};
}
// *** *** ***

export class SvgElement extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);
		this._on = null;
		Object.keys(this.props.attributes).forEach( it => {
			if ( it.startsWith('on') ) {
				if ( this._on === null )
					this._on = {doc: this.props.doc};
				this._on[it] = this.props.attributes[it];
			}
		});
	}
	// *** *** ***

	render = _ => {
		let svg = this.props.svg;
		let atr = {};
		Object.keys(this.props.attributes).forEach( it => {
			if ( !it.startsWith('on') )
				atr[it] = this.props.attributes[it];
		});
		atr.style = {...atr.style};
		return this.getEl(this.props._teg, atr, svg, this.props.text || null, this.props.children);
	};
	// *** *** ***

	getEl(teg, atr, svg, text, child) {
		let x = 0;
		let doc = this.props.doc;
		switch (teg) {
			case 'svg': x = <svg {...atr} ref={this.dom}>{text}{parseSvg(svg, child, doc)}</svg>; break;
			case 'line': x = <line {...atr}>{text}{parseSvg(svg, child, doc)}</line>; break;
			case 'rect': x = <rect {...atr}>{text}{parseSvg(svg, child, doc)}</rect>; break;
			case 'polygon': x = <polygon {...atr}>{text}{parseSvg(svg, child, doc)}</polygon>; break;
			case 'circle': x = <circle {...atr}>{text}{parseSvg(svg, child, doc)}</circle>; break;
			case 'path': x = <path {...atr}>{text}{parseSvg(svg, child, doc)}</path>; break;
			case 'text': x = <text {...atr}>{text}{parseSvg(svg, child, doc)}</text>; break;
			case 'defs': x = <defs {...atr}>{text}{parseSvg(svg, child, doc)}</defs>; break;
			case 'a': x = <a {...atr} {...Util._on_(this._on)}>{text}{parseSvg(svg, child, doc)}</a>; break;
			case 'textPath': x = <textPath {...atr}>{text}{parseSvg(svg, child, doc)}</textPath>; break;
			case 'ellipse': x = <ellipse {...atr}>{text}{parseSvg(svg, child, doc)}</ellipse>; break;
			case 'linearGradient': x = <linearGradient {...atr}>{text}{parseSvg(svg, child, doc)}</linearGradient>; break;
			case 'stop': x = <stop {...atr}>{text}{parseSvg(svg, child, doc)}</stop>; break;
			case 'tspan': x = <tspan {...atr}>{text}{parseSvg(svg, child, doc)}</tspan>; break;
			case 'g': x = <g {...atr}>{text}{parseSvg(svg, child, doc)}</g>; break;
			default: console.log('Неописанный SVG элемент:', this.props._teg);
		}
		return x;
	}
}
// *** *** ***

const parseSvg = (svg, children, doc) => {
	if ( !children )
		return null;

	let svgArr = [];
	children.forEach( (svgEl, i) => {
		let key = Math.random();
		switch (svgEl._teg ) {
			case 'svgBox':
				svgArr.push(
					<SvgBox
						doc={svg.props.doc}
						key={key}
						tree={svg.tree}
						id="box"
						svg={svg}
						{...svgEl.attributes}
						children={svgEl.children}
						_teg={svgEl._teg}
						setting={svgEl.setting}
					/>);
				break;
			case 'svgLine':
				let ref = svgEl.attributes.id === 'HL' ? o => svg.hLine = o : o => svg.vLine = o;
				svgArr.push(<SvgLine key={key} tree={svg.tree} svg={svg} {...svgEl.attributes} ref={ref} _teg={svgEl._teg}/>);
				break;
			case '#comment': break;
			default:
				svgArr.push(
					<SvgElement key={i} doc={doc} svg={svg} attributes={{...svgEl.attributes}} _teg={svgEl._teg} text={svgEl.text} children={svgEl.children || null}
					/>);
		}
	});
	return svgArr.length && svgArr;
};
// *** *** ***

export default Svg
