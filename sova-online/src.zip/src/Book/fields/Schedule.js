import React from 'react';
import autoBind from 'react-autobind';

import Util from '../common/Util';
import {spinner} from '../common/Spinner';

let _morning = 11;

// *** *** ***
class Hour extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);
		this.status = this.props.value[0] || 'F';
		this.uNamePhone = (this.props.value[1] || '').toString();
		this.notes = (this.props.value[2] || '').toString();
		this.userName = this.props.doc.props.userName;
		this.userName2 = Util.partition(this.userName, '/')[0]; // имя пользователя без домена
		this.uName = Util.partition(this.uNamePhone, '\n')[0]; // имя автора изменений без телефона
		this.uName2 = Util.partition(this.uName, '/')[0]; // имя автора изменений без домена
		let s = this.notes.toLowerCase().trim();
		if ( !this.status ||
			 (this.userName2 !== this.uName2 && this.uName2 === 'Новый Век' && (!s || s.includes('отпуск')))
		 )
			this.status = 'F';
		this.enable = this.status === 'F' || this.userName2 === this.uName2 ;
		this.state = {status: this.status};
	}

	showDlg = e => {
		let doc = this.props.doc;
		let status, notes;
		if ( this.status === 'F' ) {
			status = doc.getField('status_fd');
			notes = doc.getField('notes_fd') || this.notes;
			return this.runXhrHourSave(status, notes);
		}
		let h = 215;
		let oldSt = this.status;
		status = this.status.toLowerCase();
		if (status === 'm')
			status = 'a';
		doc.dlg.show(
			`${this.props.j+1}.${('0'+(this.props.mm+1)).slice(-2)}.${this.props.yy} ${this.props.r+_morning}:00`, // заголовок
			{status: status, userName: this.uNamePhone, notes: this.notes},
			{ 	style: {position: 'fixed', zIndex: 1000, width:250, top: 'calc(100vh / 2 - 90px)', left: 'calc(100vw / 2 - 90px)', height:h, overflow: 'hidden' },  //  стиль всего диалога
				buttons: ['OK+|Y', 'отмена'],
				cmButton: _ => {
					if (this.enable) {
						status = (doc.dlg.getField('status').split('|')[0]) || 'F';
						status = status === oldSt.toLowerCase() ? oldSt : status;
						notes = doc.dlg.getField('notes');
						if (status !== this.status || notes !== this.notes) {
							this.runXhrHourSave(status, notes);
						}
					}
					else
						/*doc.msg.box*/ alert('Нельзя изменить чужую аренду');
				},
			},
			{width: 240, height: h-65}, // стиль области данных
			JSON.parse(doc.getField('cellProps_fd')),
			null, null, null, 'dlgButtons2'
	    );
	};
	// **** *** ***

	afterSave = (status, notes) => {
		this.status = status;
		this.uNamePhone = this.uName = this.userName; // имя автора изменений
		this.uName2 = Util.partition(this.uName, '/')[0]; // имя автора изменений без домена
		this.notes = notes;
		this.props.setCell(this.props.i, [status, this.uNamePhone, notes]);
		this.setState({status: status});
//		console.log(this.status, this.classN);
	}
	// *** *** ***

	render = _ => {
		let dt = new Date(this.props.yy, this.props.mm,  this.props.j+1);
		this.cl = Util.anyMobile ? 'cell' : 'bigCell';
		this.cl += !this.props.c13 && dt.getTime() === new Date().setHours(0, 0, 0, 0) ? ' b' : ' '; // 'b' - текущий день
		this.classN = this.cl + ( this.userName2 === this.uName2 && this.status !== 'F' ? ('m'+this.status) : this.status );
		let mm = Util.anyMobile ? '' : ':00'
		if (this.props.c13)
			this.label = this.props.r + _morning + mm;
		else if (!dt.getDay()) // воскресенье
			this.label = this.props.r + _morning + mm;
		else
			this.label = '';
		let cellTx = Util.anyMobile ? '' : <span><br/>{this.notes || ''}<br/>{this.uName || ''}</span>;
		return <div className={this.classN} onClick={this.showDlg}>{this.label}{cellTx}</div>;
	}
	// *** *** ***

	runXhrHourSave(status, notes, force='') {
		let data = status + '|' + notes;
		let url = `/saveHour?${this.props.dKey}_${this.props.j+1}_${this.props.r+_morning}_${force}`;
		fetch(url, { method: 'post', body: data, credentials: 'include' } )
			.then ( response => {
				if ( response.status === 409 ) { // коллизия
					response.text()	// тоже промис
						.then ( text => this.props.doc.msg.box( 'ПЕРЕЗАПИСАТЬ ДОКУМЕНТ?\n' + text, 'Конфликт при сохранении', ['Да+|Y', 'Нет'] )
							.then ( _ => this.runXhrHourSave(status, notes, 'force') )
						)
						.catch ( _ => alert('Конфликт при сохранении') );
				}
				else {
					if ( response.status !== 200 ) {
						alert(`DocSave-error-status ${response.status}\nurl:${url}`);
					}
					else {	// УСПЕШНОЕ ОКОНЧАНИЕ СОХРАНЕНИЯ
						this.afterSave(status, notes);
					}
				}
			})
			.catch ( error => alert(`DocSave-error:${error}\n\nurl:${url}`) );
	}
	//**********
}

// *** *** ***
// *** *** ***

class Schedule extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);
		[this.title, this.url, this.rType, this.month, this.dKey] = this.props.header.split('|');
		let ls =  this.dKey.split('_');
		this.mm = parseInt(ls[1], 10) - 1;
		this.yy = parseInt(ls[2], 10);
		this.state = { spinner: false };
		this.props.doc.roomsLoad = this.props.doc.roomsLoad || [];
		this.noLoad = true;
	}
	//*** *** ***

	componentDidMount = _ => {
		if ( !this.noLoad &&
			!this.cells &&
			!this.waitLoad &&
			!Util.hide(this.props.doc, this.props.name) ) {
				this.waitLoad = true;
				this.loadTable();
		}
	}
	shouldComponentUpdate = (nextProps, nextState) => {
		if( !this.noLoad &&
			!this.cells &&
			!this.waitLoad &&
			!Util.hide(this.props.doc, this.props.name) ) {
				this.waitLoad = true;
				this.loadTable();
		}
		return true;
	};

	loadTable() {
		if (this.err)
			return;
		let n = Util.partition(this.props.xName, '_')[1];
		let prev = parseInt(n, 10) - 1;
		this.props.doc.roomsLoad[n] = true;
		if (this.props.doc.roomsLoad[prev]) {
			setTimeout(this.loadTable, 25);
			return;
		}
		// через 1.0с включить "Загрузка", если waitLoad=true
		setTimeout( _ => this.waitLoad ? this.setState({spinner: true}) : 0, 500 );
		this.forceUpdate();

		Util.jsonByUrl( 'api.get?loadMonth&' + this.dKey )
			.then( resp => {
				this.waitLoad = false;
				this.props.doc.setField(this.props.xName + '_key', this.dKey);
				this.cells = resp.slice();
				this.setState( {spinner: false} );
				this.props.doc.roomsLoad[n] = false;
			})
			.catch( e => {
				this.err = this.props.xName + ': ' + this.dKey + ': ' + e;
				console.log(e);
				this.setState( {spinner: false} );
				this.props.doc.roomsLoad[n] = false;
				this.waitLoad = false;
			});
	}
	// *** *** ***
	setCell = (i, cell) => this.cells[i] = cell;

	render() {
		let doc = this.props.doc;
		let c13, dd, date_fd;
		if (doc.state.class_fd) {
			date_fd = doc.getField('date_fd');
			if (date_fd) {
				c13 = doc.state.class_fd;
				dd = date_fd.split('-')[2];
				dd = parseInt(dd, 10);
			}
		}
		let rows, load = null;
		let ls = this.cells;
		if ( !this.noLoad && ls && ls.length && ls[0] ) {
			rows = [];
			let nc = this.props.btn; // this.props.btn - число кнопок в строке
			let i = 0;
			let days = [];
			let j, r;
			let cols = [];
			for (j = 0; j < nc; j++) {
				if (c13) {
					if (dd === j+1)
						days[j] = <div key={j} style={{transform: 'rotate(270deg)'}} className={'cellDay'}>{Util.partition(this.title, '\xa0')[0]}</div>;
				}
				else
					days[j] = <div key={j} className={Util.anyMobile ? 'cellDay' : 'bigCellDay'}>{j+1}</div>;
			}
			rows[0] = <div key="row1" className="schTable">{days}</div>;

			for (r = 0; r < Math.floor(ls.length / nc) + 1; r++) {
				cols = [];
				for (j = 0; j < nc && i < ls.length; j++, i++) {
					if (!c13 || dd === j+1)
						cols[j] = 	<Hour c13={c13} key={i} i={i} value={ls[i]} r={r} j={j} doc={doc} mm={this.mm} yy={this.yy} dKey={this.dKey}
										setCell={this.setCell}
									/>;
				}
				rows[r+1] = <div key={r} className="schTable">{cols}</div>;
			}
			rows[r] = <div key="row2" className="schTable">{days}</div>;
			// rows[r+1] = <hr key="row3" style={{margin: '2px 0 5px 0'}}/>;
		}
		else {
			rows = ' ';
			load = <div className='btn' onClick={_ => Util.runCmd(doc, 'loadRoom', this)}>Загрузить</div>
		}
		let showL = doc.getField('show_FD') !== '1';
		let showR = doc.getField('show_FD') !== '10';

		let spin = this.waitLoad && this.state.spinner;
		let title = <div style={{width: 120, padding: '0 10px', display: 'table-cell', color: 'blue', font: 'normal 14px Verdana', letterSpacing: 1}}>{this.title}</div>;
		let header = spin || c13 ? null :
			<div style={{margin: 'auto', display: 'table', paddingTop:5}}>
				{load}
				{title}
				<div className="exp" style={showL ? {} : {cursor: 'default'}} onClick={ _ => showL && this.onclick(-1) }>{showL && String.fromCharCode(9668)}</div>
				<div className="chMonth">{this.month}</div>
				<div className="exp" style={showR ? {} : {cursor: 'default'}}  onClick={ _ => showR && this.onclick(1) }>{showR && String.fromCharCode(9658)}</div>
				{load || title}
			</div>;

		return (
		<div style={{...this.props.style}} className={spin ? 'norows' : (c13 || 'shRow')}>
			{header}
			{ spin ? spinner(false, false) : this.err ? this.err : rows }
		</div>
		);
	}
	//*** *** ***

	onclick = dir => {
		let doc = this.props.doc;
		let i = parseInt(doc.getField('show_FD'), 10);
		if ( (i === 1 && dir < 0) || (i === 10 && dir > 0) )
			return;
		let nRooms = parseInt(doc.getField('nRooms_FD'), 10);

		Object.keys(doc.register).forEach( xName => {
			if ( doc.register[xName].props.showCol === this.props.showCol ) {
				let nr = parseInt( Util.partition(xName, '_')[1], 10 );
				let nr1 = nr + dir*nRooms;
				window.showRooms[nr1] = window.showRooms[nr];
				window.showRooms[nr] = false;
				doc.register['SCH_' + nr1.toString()].noLoad = doc.register[xName].noLoad;
			}
		});
		doc.setField('show_FD', (i+dir).toString());
		doc.forceUpdate();
	};
}
// *** *** ***
export default Schedule;
