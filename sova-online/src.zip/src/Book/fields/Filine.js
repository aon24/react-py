import React from 'react';
import autoBind from 'react-autobind';

import Util from '../common/Util';

class Filine extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.state = {
			audio: false,
			runUpload: false,
		};

		this.progress = null;
		this.invalid = false;

		try {
			if ( !this.props.xName )
				return;

			if (this.props.fileObject) {
				this.f_name = this.props.fileObject.name;
				this.f_type = this.props.fileObject.type;
				this.f_size = this.props.fileObject.size;
				this.f_date_db = '';
				this.f_date_crt = Util.formatDateTime(new Date(this.props.fileObject.lastModified));

				if ( !this.f_type && this.f_name.endsWith('.7z') )
					this.f_type = 'application/x-zip-compressed';
				this.href = '';
			}
			else {
				let x;
				[	this.f_store,
					this.f_zip,
					this.f_name,
					this.f_type,
					this.f_size,
					x
				] = this.props.xValue.split('|');

				[this.f_date_db, this.f_date_crt] = Util.partition(x, '_');
				this.f_date_crt = this.f_date_crt || this.f_date_db;

				this.makeHref();
			}
		}
		catch(ex) {
			console.warn('Filine.js:', ex.message);
			this.invalid = true;
		}
	}
	//**********

	delFile(event) {
		this.props.delFile(this.props.xName)
	}
	//**********

	editFile(event) {
		let url = 'http://127.0.0.1:3080/apiget?execModule&' + this.props.dbAlias + '&' + Date.now();
		let opt = {credentials: 'include'};
			// credentials: 'include'},
			// cache: 'no-store',
			// mode: 'no-cors',
//			headers: new Headers({'Access-Control-Allow-Origin': '*'})
		// }
		fetch( url, opt )
			.then(response =>response.text()
				.then( tx =>
					console.log('=>' + tx + '<=')
				)
		 	)
			.then(tx => {
				console.log('=>' + tx + '<=');
			})
			.catch(err => {
				alert('editFile.fetch-error:' + err.message);
				console.error('editFile.fetch-error:', err);
			});
	}
	//**********
	notLook = _ => ['.doc','.docx','.xls','.xlsx','.tiff', '.zip', '.7z'].filter( it => this.href.includes(it) ).length;

	openFile(event) {
		if ( this.notLook() )
			return Util.xopen('docopen?' + this.href);

		let width = Math.min(this.props.doc.width, 1010) - 10;
		let height = Math.min(this.props.doc.height, 610) - 10;
		let st  = {
			style: {width: width, height: height, background: '#def'},
			buttons: this.href.includes('.pdf?') ? ['Открыть+|O', 'Закрыть'] : ['Открыть+|O', 'Печать|P', 'Кодировка|C', 'Закрыть'],
			cmCancel: () => this.props.doc.setFocus(this.props.doc.focus),
			cmButton: (cmd, ifr) => {
				switch (cmd) {
					case 'O':
						Util.xopen('docopen?' + this.href + '&UTF-8');
						break;
					case 'C':
						Util.xopen('docopen?' + this.href + '&windows-1251');
						break;
					default:
						ifr.contentWindow.print();
				}
			},
		};
		let stD ={width: width-130, maxHeight: height-30, overflow: 'hidden'};

		this.props.doc.dlg.show('Просмотр вложения', this.href + '&UTF-8', st, stD);
	}
	//**********

	componentWillReceiveProps(nextProps) {
		if ( !nextProps.runUpload && this.progress ) {
			delete this.progress;	// убрать прогресс-бар
			this.progress = null;
		}
		this.setState( {
			audio: this.state.audio,
			runUpload: nextProps.fileObject ? nextProps.runUpload : false // fileObject есть только у несохраненных файлов
		});
	}
	//**********

	componentWillUpdate(nextProps, nextState) {
		if ( !this.state.runUpload && nextState.runUpload ) {
			// переход из состояния "не runUpload" в runUpload - стартуем xhr
			let formData = new FormData();
			formData.append("attachment", this.props.fileObject);
			const url = [
				'upload?' + this.props.dbAlias,
				this.f_size,
				this.f_date_crt,
				this.props.docRef || this.props.unid
			].join('&');

			this.props.fileObject.filineErr = null;
			this.runXHR(url, formData);
		}
	}
	//**********

	render() {
		if (this.state.invalid)
			return  (<div className="filine-blank">{'invalid field: ' + this.props.xName}</div>);

    	const lsw = ['9.5cm', '1.7cm', '4.5cm', '0.85cm'];
		let opn = null;
		let fn;
		let dateOrProgress;

		if ( !this.props.fileObject ) { // fileObject есть только у несохраненных файлов
			if (!this.state.audio) {
				fn =
					<a
						target="_blank"
						rel="noopener noreferrer"
						href={this.href}
						title="Открыть файл по ссылке. Для сохранения файла на диск нажмите правую кнопку мыши и выберите 'Сохранить как...'"
					>
						{this.f_name}
					</a>;
			}
			else {
				fn =
					<audio
						controls={'controls'}
						autoPlay={'autoplay'}
						src={this.href}
					/>;
			}
			if (this.f_type.indexOf('audio') < 0) {
				let look = this.notLook() ? ['сохранить на диск', 'скачать'] : ['Открыть для просмотра или печати', 'быстрый просмотр']
				opn =
					<span
						style={{color: 'blue', cursor: 'pointer'}}
						onClick={this.openFile}
						title={look[0]}
					>
						{look[1]}
						<br/>
					</span>;
			}
			else {
				opn =
					<span
						style={{color: 'green', cursor: 'pointer'}}
						onClick={ () => this.setState({audio: !this.state.audio}) }
						title={this.state.audio ? 'Стоп' : 'Пуск'}
					>
						{this.state.audio ? 'остановить запись' : 'прослушать запись'}
						<br/>
					</span>;
			}
			dateOrProgress =
				<div style={ {width: lsw[2]} } title={'Запись в базу ' + Util.dtRus(this.f_date_db)}>
					{opn}
					{Util.dtRus(this.f_date_crt)}
				</div>;
		}
		else {	// новый несохраненный файл
			fn = this.f_name;

			if ( this.state.runUpload ) {
				dateOrProgress =
					<div style={ {width: lsw[2]} }>
						<progress
							value="0"
							max="1"
							style={{width: lsw[2]}}
							ref={ o => this.progress = o }
						/>
					</div>;
			}
			else {
				dateOrProgress =
					<div style={ {width: lsw[2]} } title={'Файл не сохранен в базе'}>
						{Util.dtRus(this.f_date_crt)}
					</div>
			}
		}
		//***********

		return (
		<div className="filine">
			<div style={ {width: lsw[0]} }>
			 {fn}
			</div>
			<div style={ {width: lsw[1]} }> {this.f_size} </div>
			{dateOrProgress}
			<span
				onClick={this.delFile}
				style={{ width: lsw[3], display: this.props.readOnly || this.state.runUpload ? 'none' : 'table-cell' }}
				title="Удалить вложение" >
					&times;
			</span>
{/*
				<span
				onClick={this.editFile}
				style={{ color: 'blue', width: lsw[3], display: this.props.readOnly || this.state.runUpload ? 'none' : 'table-cell' }}
				title="Редактировать вложение" >
					E
			</span>
*/}
		</div>);
	}
	//**********

	runXHR (url, formData) {
		const xhr = new XMLHttpRequest();
		xhr.open('post', url, true);
		xhr.withCredentials = true;

		xhr.addEventListener('load', () => {
			if ( xhr.status === 200 )
				this.uploadSuccess(xhr.responseText);
			else
				this.uploadError(xhr.status + ' ' + xhr.responseText);
		});
		xhr.addEventListener('error', err => this.uploadError(err.message || err) );
		xhr.upload.addEventListener('progress', e => {
			if (this.progress) {
				this.progress.value = e.loaded;
                this.progress.max = e.total;
			}
		});
		xhr.send(formData);
	}
	//**********

	uploadSuccess (rt) {
		try {
			let ls = rt.split('&'); //def uploadFile: '&'.join([idbl, fsName, tm, fzip]
			let newFieldName = this.props.filter + ls[0];
			this.f_store = ls[1];
			this.f_date_db = ls[2];
			this.f_zip = ls[3] + ( ls[3].length === 1 && this.props.docRef ? 'R' : '');

			this.makeHref(ls[0]);
			this.setState( {runUpload: false} );
			// file|0R|01 - Крылья.mp3|audio/mpeg|3617275|2017-03-27 01:50:23|2011-07-07 13:56:19
			let newXValue = [
				this.f_store,
				this.f_zip,
				this.f_name,
				this.f_type,
				this.f_size,
				this.f_date_db,
				// this.f_date_crt
				].join('|');
			this.props.uploadDone(this.props.xName, newFieldName, newXValue);
		}
		catch(ex) {
			console.log('Filine.js: invalid responseText of xhr', ex.message);
			this.uploadError('uploadSuccess - exception after upload');
		}
	}
	//**********

	makeHref(new_idbl) {
		// dbAlias, unid, idbl, fsName, fzip, attype, atsize
		/*
		 	RF.AKK/OG_2017&
			D9B56A19AEA65A2E07BD0F3FA4AACD57&
			BD25E5EDED13534B209036B761C62F49&
			file&
			Z&
			text/plain&
			87774&
			UTF-8'
		*/
		this.href = ['download/' + this.f_name + '?' + this.props.dbAlias,
				this.props.unid,
				new_idbl || this.props.xName.split('_')[1],
				this.f_store,
				this.f_zip,
				this.f_type,
				this.f_size
			].join('&');
	}
	//**********

	uploadError(mess) {
		this.props.fileObject.filineErr = mess || 'error';
		this.setState( {runUpload: false} );
		this.props.uploadDone(this.props.xName, '', '', mess);
		console.log('uploadError:', mess);
	}
	//**********
}
//***************************

export default Filine;
