import React from 'react';
import autoBind from 'react-autobind';

import Util from '../common/Util';

class Text extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.shadow = null;
		this.input = null;
		this.savedH = 16;
		this.sep = this.props.sep || '|';

		if ( !['lbse', 'lbme'].includes(this.props.type) || this.props.readOnly ) {
			this.lb = false;
			this.placeholder = 'Введите текст';
		}
		else {
			this.lb = true;
			this.multi = this.props.type === 'lbmd';
			this.placeholder = 'Выбор значения из списка: <Alt-стрелка вниз>';
		}
		this.state = {
			focusOn: false,
			height: 0,
			text: this.props.xValue || '', //_
		};
	}
	// *** *** ***

	setValue = value => {
		let s = this.props.type === 'dt' ? Util.dtRus(value) : value;
		this.updateComp( s || '' ); //_
	};
	// *** *** ***

	getValue = param => {
		let s = this.state.text;	//_ .replace(/\n/g, '¤');
		if ( this.props.type === 'dt' )
			return  param ? Util.dtRus(s) : Util.dtDB(s);
		else
			return param === 'list' ? [s, this.selectionStart, this.selectionEnd] : s;
	};
	// *** *** ***

	setFocus = _ => { this.setState( {focusOn: true} ); this.input.focus(); };

	// *** *** ***

	changeDropList(newList) {
		if ( this.props.readOnly )
			return this.setState ({ dropList: [] });

		if ( this.lb ) {
			let ls = this.props.ls;
			if ( typeof ls === 'string' ) { // строка - url
				if ( ls.includes('|||') ) {
					let [fi, t] = ls.split('|||');
					ls = t.replace(/{FIELD}/g, this.props.doc.getField(fi));
				}
				else
					ls = newList || ls;
				Util.jsonByUrl(ls)
					.then( jsn => this.setState ({ dropList: jsn || [] }) )
					.catch ( mess => console.error('Text.js: Util.jsonByUrl:' + mess) );
			}
			else
				this.setState ({ dropList: newList || [] });
		}
	}
	// *** *** ***

	componentDidMount() {
		this.changeDropList(this.props.ls);
		this.updateComp( this.state.text );
	}
	// *** *** ***

	onkeydown(e) {
		if ( this.props.readOnly )
			return;

		let upDowm = Util.upDown(e, false); // не очищать event
		if ( upDowm === 'up' ) {
			if ( this.input.selectionStart === 0 )
				return this.props.doc.setFocus(this.props.myRow - 1);
		}
		else if ( upDowm === 'down' ) {
			if ( this.input.selectionStart >= this.state.text.length )
				return this.props.doc.setFocus(this.props.myRow + 1);
		}

		if ( this.props.type === 'tx' ) {
			if ( e.keyCode === 13 && this.props.keyCode_13 ) {
				e.stopPropagation();
				e.preventDefault();
				Util.runCmd(this.props.doc, this.props.keyCode_13, this.state.text, e.ctrlKey);
			}
			return;
		}

		if ( (e.keyCode === 40 && e.altKey) ||
			 (e.keyCode === 13 && ( (!e.shiftKey && !this.props.shiftEnter) || (e.shiftKey && this.props.shiftEnter)  ) ) )
				this.showListBox(e);
	}
	// *** *** ***

	onkeypress(event) {
		if (event.ctrlKey || !this.lb || this.state.text)
			return;

		let key = event.key.toLowerCase();

		for ( let lab of this.state.dropList ) {
			if ( lab.toLowerCase().startsWith(key) ) {
				event.stopPropagation();
				event.preventDefault();
				this.updateValue(lab);
				break;
			}
		}
	}
	// *** *** ***

	showListBox(e) {
		e.stopPropagation();
		e.preventDefault();

		let oldVal = this.state.text;
		let dropL2 = this.state.dropList.map( it => it.split(this.sep)[0] );
		let checked = [];
		let filtered = [];
		oldVal.split('\n').forEach( it => {
			let i = dropL2.indexOf(it.split(this.sep)[0]);
			if ( i >= 0 )
				checked.push(i);
			else
				filtered.push(it);
		});
		this.updateComp(filtered.join('\n'));

		this.props.doc.msg.list ( this.state.dropList,
			'Выберите значение',
			{ multi: this.props.type === 'lbme', checked: checked, sep: this.sep }, this.props.small )
			.then( res => {
				if (res)
					this.updateValue(res);
				this.input.focus();
			})
			.catch( _ => {this.updateComp(oldVal); this.input.focus();} );
	}
	// *** *** ***

	updateValue (newValue) {
		let ls = this.state.text.split('\n');
		let s = '';
		newValue.replace(/¤/g, '\n').split('\n').forEach( it => { //_
			let nv =  it.includes(this.sep) ?
				( this.props.alias ? it.split(this.sep)[1] : it.split(this.sep)[0] )
				:
				it;

			if ( !ls.includes(nv) )
				s += nv + '\n';
		});
		if (s) {
			// № 1453 -ТО от 22.02.2018  При замене проекта резолюции (выборе еще раз в том же поле другого проекта) - он добавляется в конец, что очень не удобно
			// добавлено  && this.props.type === 'lbme'
			s = (this.state.text && this.props.type === 'lbme' ? this.state.text + '\n' : '') + s.slice(0,-1);
			this.updateComp(s);
		}
		Util.recalc(this, s ? s : this.state.text);
	}
	// *** *** ***

	updateComp(text) {
		if ( this.shadow  ) {
			this.shadow.value = text;
			if ( this.shadow.scrollHeight )
				this.savedH = this.shadow.scrollHeight;
			this.setState({
				text: text,
				height: this.savedH + 2
			});
		}
	}
	// *** *** ***

	onselect = e => {
		this.selectionStart = this.input.selectionStart;
		this.selectionEnd = this.input.selectionEnd;
	}
	// *** *** ***

	render = _ => {
		let lb = !this.lb ?
			null
			:
			<div
				className="btn-lb-zone"
				onClick={ e => this.showListBox(e) }
			>
				<div className="btn-lb" style={{marginLeft: 3}}/>
			</div>;
		return (
		<div style={{ ...this.props.style}} {...Util._on_(this.props)}>
			<div
				className={ (this.props.ttaClassName || 'tta') + (this.state.focusOn ? ' on-focus' : '') + (this.props.readOnly ? ' read-only' : '')}
				style={{...this.props.ttaStyle }}
			>
				<div style={{ ...this.props.ttaStyle, height: this.state.height, display: 'table-cell'}}>
					<textarea
						tabIndex={this.props.readOnly ? -1 : '0'}
						placeholder={this.props.readOnly ? '' : this.props.placeholder || this.placeholder}
						value={this.state.text}
						onKeyDown={this.onkeydown}
						onKeyPress={this.onkeypress}
						onChange={ e => this.updateComp(e.target.value) }
						onFocus={ _ => this.setState({ focusOn: true }) }
						onSelect={ e => this.onselect(e) }
						onBlur={ _ => this.setState({ focusOn: false }) }
						style={{ height: this.state.height + 0, margin:0 }}
						ref={ o => this.input = o }
						readOnly={this.props.readOnly}
					/>
					<textarea
						value={this.state.text}
						onChange={() => null }
						style={{ display: 'block', visibility: 'hidden', height: 1, overflow: 'hidden'}}
						ref={ o => this.shadow = o }
					/>
				</div>
				{lb}
			</div>
		</div>);
	}
	// *** *** ***
}

export default Text;
