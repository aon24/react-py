import React from 'react';
import autoBind from 'react-autobind';

import Filine from './Filine'
import {Util} from '../common/Util';
//***************************

class FileShow extends React.Component {

	constructor(props) {
		super(props);
		autoBind(this);

		this.labelBlank = 'поле для присоединенных файлов';
		this.nDescr = 0;
		this.fileArr = [];
		this.filter = this.props.fileShow; // 'FILES1_', FILES2_'...
		this.init();
		this.state = {runUpload: false};
	}
	//**********

	initialize = _ => { this.init(); this.forceUpdate(); }

	//**********

	init() {
		this.fileArr.forEach( (it, i) => delete this.fileArr[i] );
		this.fileArr = [];

		// имя поля:  FILES1_2AEA4C32A25B5C2018EB109A63253931
		// значение:  file|ZR|VoiceMessage.wav|audio/wav|502938|2017-04-14 14:24:22|2017-02-07 20:19:06

		// sorting by date:
		let forSort = []; // только имена полей
		Object.keys(this.props.doc.fieldValues).forEach ( field => {
			if ( field.startsWith(this.filter) ) { // filter = 'FILES1_' etc
				const fil = this.props.doc.fieldValues[field].split('|');
				if ( fil.length === 6 )
					forSort.push(fil[5].split('_')[0] + field + '|' + field); // дата-время записи в базу + fileUnid
				else
					console.warn('FileShow.js: недействительная структура поля:', field, this.props.doc.fieldValues[field]);
			}
		});
		// создаем список полей с описанием файлов:
		forSort.sort().forEach(it => { // создаем this.fileArr - отсортированный массив описаний
			let fi = it.split('|')[1];
			this.fileArr.push ({
				key: this.filter + this.nDescr++,
				xName: fi,
				oldValue: this.props.doc.fieldValues[fi],
				newValue: this.props.doc.fieldValues[fi],
			});
		});
	}
	//**********

	addFiles(event) {
		// в хроме есть фича. Если добавить вложение, затем удалить, затем снова его же добавить,
		// то события event.target.files НЕ происходит. Но можно перетащить мышкой
		let files = event.dataTransfer ? event.dataTransfer.files : event.target.files;

		if ( !files || this.props.readOnly )
			return;

		if ( !files[0].size )
			return this.props.doc.msg.box('Нельзя присоединить файл нулевой длины');

		for ( let f of files ) {
			let key = this.filter + this.nDescr++;
			this.fileArr.push ({
				key: key,
				xName: key,
				fileObject: f,
			});
		}
		this.forceUpdate();
    }
	//**********

	delFile(xName) {
		if ( !this.props.readOnly ) {
			this.fileArr.forEach( it => {
				if ( xName === it.xName )
					it.del = true;
			} );
			this.forceUpdate();
		}
	}
	//**********

	getNewValues(flagSave) {
		// возвращает json измененных полей .."field1": ["oldV", "newV"], ...
		// файлы не могут меняться. Они могут удалиться или добавиться
		let s = '';
		this.fileArr.forEach( it => {
			if ( it.del ) {
				if ( it.oldValue )
					s += Util.addJson( it.xName, it.oldValue, '' );
			}
			else if ( !it.oldValue && it.newValue)
				s += Util.addJson( it.xName, '', it.newValue );
			else if ( it.fileObject && !flagSave)
				s += Util.addJson( it.xName, '', 'Файл "' + it.fileObject.name + '" не сохранен' );
		});
		return s;
	}
	//**********

	hasAtt() {
		// возвращает имена файлов, включая несохраненные
		let ls = [];
		this.fileArr.forEach( it => {
			if ( !it.del ) {
				if (it.fileObject)
					ls.push(it.fileObject.name);
				else
					ls.push(it.oldValue.split('|')[2]);
			}
		} );
		if ( ls.length )
			return ls.join(', ');
	}
	//**********

	startUpload() {
		// вызывается из родителя по каманде Save
		// возвращает this.run = false, если старттовать нечего, true - Upload запущен(надо ждать окончания)
		this.run = false;
		this.uploadError = false;

		if ( this.props.readOnly ) {
			return;
		}
		if ( this.state.runUpload ) {
			this.run = true;
			return;
		}
		for ( let i = 0; i < this.fileArr.length; i++) {
			if ( this.fileArr[i].fileObject && !this.fileArr[i].del) {
				this.setState( {runUpload: true} ); // старт upload для всех компонент
				this.run = true;
				return;
			}
		}
	}
	//**********
	// вызывается из детей при окончании uploda
	uploadDone(tempFieldName, newFieldName, newXVal, errMsg) {
		if (errMsg) {
			this.uploadError = true;
			this.props.doc.msg.error('Ошибка при отправке файла на сервер:\n\n' + errMsg)
		}
		else
			this.fileArr.forEach( it => {
				if ( tempFieldName === it.xName ) {
					it.xName = newFieldName;
					it.newValue = newXVal;
					delete it.fileObject;
					it.fileObject = null;
				}
			} );

		let wait = false;
		this.fileArr.forEach( it => {
			if ( it.fileObject && !it.fileObject.filineErr ) {
				wait = true;	// есть незавершенные upload'ы
				this.forceUpdate();
			}
		});
		if ( !wait ) {
			// сообщить родителю, что в этом файлшоу все upload'ы отработали
			this.setState ( {runUpload: false} );
			this.run = false;
			this.props.uploadDone(this.filter);
		}
	}
	//**********

	render() {
		const fls = this.fileArr.map( it => {
			return it.del ? null :
				<Filine
					key={it.key}
					xName={it.xName}
					xValue={it.newValue}
					fileObject={it.fileObject}
					dbAlias={this.props.doc.dbAlias}
					unid={this.props.doc.unid}
					docRef={this.props.doc.getField('ref') || null}
					delFile={this.delFile}
					runUpload={this.state.runUpload}
					uploadDone={this.uploadDone}
					filter={this.filter}
					readOnly={this.props.readOnly}
					doc={this.props.doc}
				/>
			}).filter( it => it );

		let ttaFileShow = this.props.ttaFileShow || ( 'tta' + (this.props.readOnly ? ' read-only' : '') );
		return (
			<div className={this.props.className} style={{...this.props.style}}>
				<div className="row">
					<div
						className={this.props.readOnly ? 'label' : 'fileLabel'}
						style={{minWidth: this.props.wl || 0, width: this.props.wl || 'auto', padding: '2px 3px 8px 0'}}
					>
						<input
							type="file"
							multiple
							onChange={this.addFiles}
							style={{display: 'none'}}
							ref={ o => { if ( !this.props.readOnly ) this.btnFile = o } }
						/>
						<span
							onClick={() => this.btnFile && !this.props.readOnly && this.btnFile.click() }
							style={{cursor: this.props.readOnly ? 'default' : 'pointer'}}
						>
							{this.props.label}
						</span>
					</div>
					<div
						className={ ttaFileShow }
					>
						{fls.length ? fls : <div className="filine-blank">{this.labelBlank}</div>}
					</div>
				</div>
			</div>
		);
	}
	//**********
}
//***************************

export default FileShow;
