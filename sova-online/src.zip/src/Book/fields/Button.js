import React from 'react';
import autoBind from 'react-autobind';
import Util from '../common/Util'

class Button extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.state = {
			focusOn: false,
			label: this.props.label,
			cmd: this.props.cmd,
			title: this.props.title,
			param: this.props.param,
			className: this.props.className,
		};
	}
	// *** *** ***

	setValue = p => this.setState( {
		label: p.label || this.state.label,
		cmd: p.cmd || this.state.cmd,
		title: p.title || this.state.title,
		param: p.param || this.state.param,
		className: p.className || this.state.className,
	} );

	setFocus = _ => { this.setState( {focusOn: true}); this.div && this.div.focus(); }

	onclick = e =>  this.props.btnClick ?
		this.props.btnClick(this.props.doc, this.state.cmd, this.state.param, e.ctrlKey)
		:
		Util.runCmd(this.props.doc, this.state.cmd, this.state.param, e.ctrlKey);

	// *** *** ***

	render() {
		let ls;
		if ( this.state.label.includes('\n') ) {
			ls = [];
			this.state.label.split('\n').forEach( (it, ii) => {
				if ( ii )
					ls.push( <span key={ii}><br/>{it}</span> );
				else
					ls.push( this.props.s2 ? <span key={ii}><b>{it}</b></span> : <span key={ii}>{it}</span> );
			});
		}
		else
			ls = this.props.s2 ? <b>{this.state.label}l</b> : this.state.label;

		return (
			<div style={{ cursor: 'pointer', ...this.props.style }}
				tabIndex="1"
				className={ (this.state.className || 'rsvTop') + (this.state.focusOn ? ' on-focus' : '') }
				onClick={ this.onclick }
				ref={ o => this.div = o }
				title={this.state.title}
			>
				{ls}
			</div>
		);
	}
	// *** *** ***
}

export default Button;
