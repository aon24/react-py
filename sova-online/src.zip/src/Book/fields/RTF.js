import React from 'react';
import autoBind from 'react-autobind';
import {makeControl} from '../common/boxing';

class RTF extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);
		this.state = {rtfText: this.props.xValue}; //_
	}
	setValue = rtfText => this.setState({rtfText: rtfText}); //_

	render()  {
		let box = rtf(this.state.rtfText, this.props.doc, this.props.readOnly, null);
		return box ?
			<div className={this.props.className} style={{...this.props.style}}>{box}</div>
			:
			null;
	}
}
// *** *** ***

export const rtf = (rtfText, doc, readOnly, wl) => {
	let re = /{_[\s\S]+?_}/g;

	let box;
	let m =  rtfText.match(re); // массив элементов
	if ( !m )
		return rtfText;

	let ls =  rtfText.split(re); // массив текстов между элементами
	if ( ls[0] ){
		if ( ls[0].includes('\n') ) {
			box = [ ls[0].split('\n').map( (it, i) => <span key={'_i'+i}>{i ? <br/> : null}{it}</span>) ];
		}
		else
			box = [ls[0]];
	}
	else
		box = [null]; // текст перед первым элементом

	m.forEach( (it, i) => {
		let item;
		try {
			let td2 = JSON.parse(it.slice(2, -2));
			item = makeControl(i, td2, doc, readOnly, wl);
		}
		catch(ex) {
			item = 'Ошибка rtf:' + ex.name + ":" + ex.message + '<->' + it.slice(1, -1);
		}
		box.push(item); // элемент
		if ( ls[i+1] ) { //текст после элемента
			if ( ls[i+1].includes('\n') )
				box.push( ls[i+1].split('\n').map( (it, ii) => <span key={i+'i'+ii}>{ii ? <br/> : null}{it}</span>) );
			else
				box.push(ls[i+1]);
		}
	});
	return box;
};
// *** *** ***

export default RTF;
