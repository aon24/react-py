import React from 'react';
import {Util} from '../common/Util'

class ForDisplayOnly extends React.Component {
	constructor(props) {
		super(props);
		this.state = { text: this.props.xValue || '' };
	}
	// *** *** ***

	setValue = value => this.setState( {text: value || ''} );
	getValue = _ => this.state.text;

	// *** *** ***

	render() {
		return (
			<div style={{ ...this.props.style}} className={this.props.className}>
				{Util.splitText(this.state.text, this.props)}
			</div>
		);
	}
}
// *** *** ***

export default ForDisplayOnly;
