import React from 'react';
import autoBind from 'react-autobind';

import ListItem from '../common/ListItem';
import Util from '../common/Util';

class List extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.items = [];
		this.dom = React.createRef();
		this.state = {
			sel: 0,
			focusOn: false,
		};
	}
	 // *** *** ***

	componentDidMount = _ => this.changeDropList();

	changeDropList(newList) { // newList может быть пусто, строка, список
		let ls = this.props.ls;
		if ( typeof ls === 'string' ) { // строка - url
			if ( ls.includes('|||') ) {
				let [fi, t] = ls.split('|||');
				ls = t.replace(/{FIELD}/g, newList || this.props.doc.getField(fi));
			}
			else
				ls = newList || ls;

			Util.jsonByUrl(ls)
				.then( jsn => {
					this.items = (jsn || []).map( it => {
						let [left, right] = Util.partition(it, '|');
						return {ref: null, label: left, opt: right};
					});
					this.setState({sel: 0});
				})
				.catch ( mess => {
					let s = 'List.js: Util.jsonByUrl:' + mess;
					this.items = [{ref: null, label: s, opt: ''}];
					console.error(s);
					this.setState({sel: 0});
				});
		}
		else {
			this.items = (newList || ls).map( it => {
				let [left, right] = Util.partition(it, '|');
				return {ref: null, label: left, opt: right};
			});
			this.setState({sel: 0});
		}
	}
	// *** *** ***

	 getValue = _ => typeof this.items[this.state.sel] === 'undefined' ? (this.props.xValue || 'undefined') : this.items[this.state.sel].label;
	 setValue = sel => this.setState({sel: sel});

	 onclick = i => {
		this.setState({sel: i});
		if ( this.props.saveAlias )
			this.props.doc.setField(this.props.xName + '_ALIAS', this.items[i].opt);
		Util.recalc( this, this.items[i].label, this.items[i].opt, i);
	}
	// *** *** ***
	render () {
		let list = this.items.map( (it, i) => {
			return (
				<ListItem
					key={Math.random()}
					listItemClassName={this.props.listItemClassName}
					listItemSelClassName={this.props.listItemSelClassName}
					index={i}
					iShow={i}
					items={this.items}
					evenColor={this.props.evenColor}
					onclick={ _ => this.onclick(i) }
					ondoubleclick={ _ => {} }
					sel={ this.state.sel === i }
					ref={ o => { if (o && this.items[i]) this.items[i].ref = o;} }
				/>);
		});

		return (
			<div className={this.props.className} style={{ ...this.props.style}} ref={this.dom}>
				<div
					ref={ o => this.tta = o }
				>
					{list.length ? list : ''}
				</div>
			</div>);
	}
	//************
}

export default List;
