import React from 'react';
import {boxing} from '../common/boxing';

class JsonArea extends React.Component {
	constructor(props) {
		super(props);
		this.textOrObj = this.props.xValue;
		this.kkey = 0; // если 0, новая прорисовка прорисует тот же объект. Если мач.рандом, каждый рендер создаст новый объект
		this.readOnly = this.props.readOnly;
	}
	// *** *** ***

	getValue = _ => this.textOrObj;
	setValue = (value, kkey) => {
		this.textOrObj = value;
		this.kkey = kkey || 0;
		this.readOnly = kkey ? this.props.doc.rsMode !== 'edit' : this.props.readOnly;
		this.forceUpdate();
		};

	// *** *** ***

	render = _ => {
		let row = null;
		if (this.textOrObj) {
			if (typeof this.textOrObj === 'string') {
				try {
					row = JSON.parse(this.textOrObj);
				}
				catch(ex) {
					row = [{div: `Error in field JSON(${this.props.xName})\n${ex.name}: ${ex.message}`, br: 1, style: {color: 'red'}}, {div: this.textOrObj}];
				}
			}
			else {
				row = this.textOrObj;
			}
		}
		return (
			<div style={{ ...this.props.style}} className={this.props.className}>
				{ row && boxing(row, this.props.doc, this.readOnly, 0, 0, this.kkey)[0] }
			</div>);
	}
}
// *** *** ***

export default JsonArea;
