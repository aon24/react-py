import React from 'react';
import autoBind from 'react-autobind';
import Util from '../common/Util';
import {boxing} from '../common/boxing';
import {spinner} from '../common/Spinner';

class Row extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);
		this.state = { expand: this.props.expand };
	}
	// *** *** ***

// getDerivedStateFromProps = (next) => { // React v17
	componentWillReceiveProps = (next) => {
		this.setState({expand: next.expand || this.state.expand});
	}

	setExpand = e => {
		e.stopPropagation();
		this.setState({expand: !this.state.expand});
	}
	// *** *** ***

	render() {
		let expand, style;
		if ( this.props.refsDocs ) {
			expand = this.state.expand ? '▼' : '►';
			style={display: 'table-cell', cursor: 'pointer'};
		}
		else {
			expand = '\u00a0';
			style={display: 'table-cell', cursor: 'default'};
		}
		let col1 =
			<div key={9998} style={style} className="expClass" onClick={ e => this.props.refsDocs ? this.setExpand(e) : 0 }>
				{expand}
			</div>;

		let [rList, rStyle, rClass] = boxing(this.props.mainDoc, this.props.doc);
		rList.unshift(col1);

		let main =
			<div
				key={this.props.mainDoc[0]}
				className={rClass || "mRow" + (this.props.selectedDoc === this.props.mainDoc[0] ? ' selectedDoc' : '') }
				style={{...rStyle}}
				onClick={ e => this.props.rowClick(this.props.mainDoc[0]) }
			>
				{ rList }
			</div>;
		if ( !(this.props.refsDocs && this.state.expand) )
			return main;

		let refsDocs = this.props.refsDocs.map( (it, i) => {
			[rList, rStyle, rClass] = boxing(it, this.props.doc);
			rList.unshift(<div key={9998} style={{width: 16, display: 'table-cell'}}/>);
			return (
				<div
					key={it[0]}
					className={(rClass || "rRow") + (this.props.selectedDoc === it[0] ? ' selectedDoc' : '') }
					onClick={ e => this.props.rowClick(it[0]) }
					style={{...rStyle}}
				>
					{ rList }
				</div>
			);
		});

		return (
			<div style={{display: 'table-row-group'}}>
				{main}
				{refsDocs}
			</div>
		);
	}
}
// *** *** ***

class View extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.state = { spinner: false };
		this.mainDocs = [];
		this.refsDocs = [];
		this.viewStyle = this.props.viewStyle || {};
		this.filtered = this.props.filtered || '';
		this.offset = this.props.offset || '0';
		this.limit = this.props.limit || '50';
		this.dbAlias = this.props.dbAlias || this.props.doc.dbAlias;
		this.viewClass = this.props.viewClass;
	}
	// *** *** ***

	componentDidMount = _ => this.loadView();

	// *** *** ***

	setValue = (filtered, par) => { // value - filtered, par - offset|limit|dba|vName
		let [offset, limit, dba, viewClass] = (par || '').split('|');
		this.filtered = filtered || '';
		this.offset = offset || '0';
		this.limit = limit || '50';
		this.dbAlias = dba || this.dbAlias;
		this.viewClass = viewClass || this.viewClass;
		this.loadView();
	}

	getValue = _ => this.dbAlias + '&' + this.selectedDoc;

	// *** *** ***

	loadView() {
		// через 1.0с включить "Загрузка", если waitLoad=true
		this.waitLoad = true;
		this.header = null;
		setTimeout( _ => this.waitLoad ? this.setState({spinner: true}) : 0, 1000 );
		this.viewStyle = {...this.viewStyle, opacity: 0.2, transition: 'opacity 50ms ease'};
		this.forceUpdate();

		let url = ['api.get?loadView', this.dbAlias, this.props.xName, this.viewClass, this.offset, this.limit, this.filtered].join('&');
		if (window.owlDebug)
			console.log('Debug View.js:', url);
		Util.jsonByUrl(url)
			.then( resp => {
				// console.log(resp);
				// return;
				this.mainDocs = resp.mainDocs;
				this.refsDocs = resp.refsDocs;
				this.waitLoad = false;
				this.viewStyle = {...this.viewStyle, opacity: 1, transition: 'opacity 0.4s ease'};
				this.selectedDoc = this.mainDocs && this.mainDocs.length && this.mainDocs[0][0];
				this.setState( {i: 0, spinner: false} );

				let dbaUnid = this.selectedDoc ? this.dbAlias + '&' + this.selectedDoc : '';
				Util.runCmd(this.props.doc, 'viewLoaded', this.props.xName + '|' + dbaUnid);
				if (resp.setField) {
					let [fi, val] = Util.partition(resp.setField, '|');
					this.props.doc.setField(fi, val);
				}
			})
			.catch( e => {
				alert('loadView-error:' + e);
				console.log('loadView-error:', url, e);
				this.waitLoad = false;
				this.viewStyle = {...this.viewStyle, opacity: 1};
				this.setState( {i: 0, spinner: false} );
			});
	}
	// *** *** ***

	rowClick = unid => {
		this.selectedDoc = unid;
		this.forceUpdate();
	}

	render () {
		if ( this.waitLoad && this.state.spinner)
			return (
				<div style={{width: this.viewStyle.width, height: '90%', position: 'relative'}}>
					{spinner(false, false, 'preloaderColor')}
				</div>);

		let rows =
			this.mainDocs.map( it => {
				return (
					<Row
						key={it[0]}
						mainDoc={it}
						refsDocs={ this.refsDocs && this.refsDocs[it[0]] }
						expand={this.selectedDoc === it[0]}
						doc={this.props.doc}
						dbAlias={this.props.doc.dbAlias}
						rowClick={this.rowClick}
						selectedDoc={ this.selectedDoc }
					/>
				)}
			);

		return (
				<div style={{width: '100%', display: 'table', tableLayout: 'fixed', ...this.viewStyle}}>
					{rows}
				</div>
		);
	}
	// *** *** ***
}

export default View
