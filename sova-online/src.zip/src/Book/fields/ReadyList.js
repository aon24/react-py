import React from 'react';
import autoBind from 'react-autobind';
import {boxing} from '../common/boxing';

/* *** *** ***
Вызов:
_div( **style(height='calc(100vh - 150px)', overflow='hidden auto', display='block'),
	children=[_field('rog', 'readyList', readyList=ls)] ) #, где ls - json строка

readyList должен иметь вид (нулевой элемент - ключ для реакта):
[
	[d.unid, {...}, {...}, ...],
	[d.unid, {...}, {...}, ...],
]
*** *** ***/

class ReadyList extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.state = {list: this.props.readyList || "[]"};
	}
	// *** *** ***

	setValue = (newList) => this.setState({list: newList});

	// *** *** ***

	render () {
		let mainDocs;
		try {
			mainDocs = JSON.parse(this.state.list);
		}
		catch (e) {
			mainDocs = [];
		}
		let rows =
			mainDocs.map( (it, i) => {
			let [rList, rStyle, rClass] = boxing(it, this.props.doc);
			return (
				<div
					key={it[0]}
					className={rClass}
					style={{display: 'table-row', ...rStyle}}
				>
					{ rList }
				</div>);
			});
		let st = rows.length ? {background: 'rgba(255,255,255, 0.5)', transition: 'background 2.0s ease'} : {};
		return (
				<div style={{width: '100%', display: 'table', tableLayout: 'fixed', ...st}}>
					{rows}
				</div>
		);
	}
	// *** *** ***
}

export default ReadyList
