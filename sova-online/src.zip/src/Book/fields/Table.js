import React from 'react';
import autoBind from 'react-autobind';
import Util from '../common/Util';

class Table extends React.Component {
	constructor(props) {
		super(props);
		autoBind(this);

		this.state = { cells: this.props.xValue.split('\n') }; //_
	}
	//**********

	setValue = value => this.setState( {cells: value.split('\n')} ); //_
	getValue = _ => this.state.cells.join('\n'); //_

	//**********

	delValue(event, i) {
		event.stopPropagation();
		this.setState( { cells: this.state.cells.filter( (it, ii) => i !== ii ) } );
		Util.recalc(this, null, i);
	}
	//**********

	render() {
		let rows;
		let ls = this.state.cells;
		if ( ls.length && ls[0] ) {
			rows = [];
			let nc = this.props.btn[0]; // this.props.btn[0] - число кнопок в строке
			let i = 0;
			let width = this.props.btn[1];
			for (let r = 0; r < Math.floor(ls.length / nc) + 1; r++) {
				let cols = [];
				for (let j = 0; j < nc && i < ls.length; j++, i++) {
					let ii = i;
					let delBtn = this.props.readOnly ?
						<span className="delBtnR">{'\u00a0'}</span>
						:
						<span
							className="delBtn"
							title="Удалить"
							onClick={ event => this.delValue(event, ii) }
						>
							&times;
						</span>;
					if (this.props.field[1] === 'gr') {
						let [btnLabel, dbaUnid] = Util.partition(ls[i], '|');
						cols[j] =
							<div key={i}
								className="ground"
								style={{minWidth: width, maxWidth: width}}
								onClick={ _ => this.props.doc.dlgPreview.docPreview(dbaUnid, this.props.doc) }
							>
								{delBtn}
								{btnLabel}
							</div>;
					}
					else {
						cols[j] =
							<div key={i}
								className="ask"
								style={{minWidth: width, maxWidth: width}}
							>
								{delBtn}
								{ls[i]}
							</div>;
					}
				}
				rows[r] = <div key={r} className="grTable">{cols}</div>;
			}
		}
		else {
			rows = <div className="grTable" style={{ paddingTop: 4 }}>{'\u00a0'}</div>;
		}
		return (
		<div style={{ ...this.props.style }}>
			<div
				tabIndex="1"
				className="tta"
				style={{ padding:'1px 0 1px 1px', ...this.props.ttaStyle }}
			>
				{rows}
			</div>
		</div>
		);
	}
	//**********
}

export default Table;
