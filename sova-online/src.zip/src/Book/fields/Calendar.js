import React from 'react';
import autoBind from 'react-autobind';

import Util from '../common/Util';

class Calendar extends React.Component {
	constructor(props) {
    	super(props);
		autoBind(this);
		let i = parseInt(this.props.dayX, 10) || 29;
		this.dayX = new Date( +new Date() + 1000*3600*24*i );

	}
	//**********

	getStrDate(d) {
		return d.getFullYear() + '-' + ('0' + (d.getMonth()+1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
	}
	changeCurDate(y, m, d) {
		this.props.cur.setFullYear(this.props.cur.getFullYear() + y, this.props.cur.getMonth() + m, this.props.cur.getDate() + d);
		this.forceUpdate();
	}
	compareDates(d1, d2) {
		return d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate();
	}

	keyHandler(e) {
		if(e.altKey || e.ctrlKey)
			return;

		if ( e.keyCode === 13)			//enter
			return this.props.setDate(this.getStrDate(this.props.cur), e)
		if ( e.keyCode === 27)			//esc
			return this.props.setDate(0, e)

		switch(e.keyCode) {
		case 37: this.changeCurDate(0, 0, -1); break; //left
		case 38: this.changeCurDate(0, 0, -7); break; //up
		case 39: this.changeCurDate(0, 0, 1); break;  //right
		case 40: this.changeCurDate(0, 0, 7); break;  //down
		case 33: this.changeCurDate(0, -1, 0); break; //pg up
		case 34: this.changeCurDate(0, 1, 0); break;  //pg down
		case 36: this.props.cur.setFullYear(this.props.cur.getFullYear(), this.props.cur.getMonth(), 1); this.forceUpdate(); break; //home
		case 35: this.props.cur.setFullYear(this.props.cur.getFullYear(), this.props.cur.getMonth() + 1, 1); this.changeCurDate(0, 0, -1); break; //end
		case 32: this.props.cur.setTime( +new Date() ); this.forceUpdate(); break;		 //space
		default: break;
		}
		e.stopPropagation();
		e.preventDefault();
	}

	render() {
		let now = new Date();

		let MONTHS = 'Январь Февраль Март Апрель Май Июнь Июль Август Сентябрь Октябрь Ноябрь Декабрь'.split(' ');
		let DAYS = 'пн вт ср чт пт сб вс'.split(' ').map( (it, i) => {
			return <div className={ i < 5 ? 'c_day_name' : 'c_day_name_wknd' } key={it}>{it}</div>
		});
		let firstDayOfMonth = [];
		let curMonth = [];
		let weeks = [];

		for (let mo = 0; mo < 3; mo++) {
			firstDayOfMonth[mo] = new Date(this.props.cur.getFullYear(), this.props.cur.getMonth() + mo - 1, 1);
			curMonth[mo] = firstDayOfMonth[mo].getMonth();

			weeks[mo] = [];
			for (let we = 0; we < 6; we++) {
				let days = [];
				let key = 'mw' + mo + '_' + we + '_';

				for (let da = 0; da < 7; da++) {
					let shift = firstDayOfMonth[mo].getDay() === 0 ? 6 : firstDayOfMonth[mo].getDay() - 1;
					let dt = new Date(firstDayOfMonth[mo].getFullYear(), curMonth[mo], 1 - shift + we*7 + da);
					if (dt.getMonth() === curMonth[mo]) {
						let cls = (da > 4) ? 'c_day c_day_wknd' : 'c_day';
						if (this.compareDates(dt, now)) cls += ' c_today';
						if (this.compareDates(dt, this.props.cur)) cls += ' c_cur';
						if (this.compareDates(dt, this.dayX)) cls += ' c_dayx';
						days[da] = <div className={cls} key={key+da} onClick={ (e) => this.props.setDate(this.getStrDate(dt), e) }>{'' + dt.getDate()}</div>;
					} else {
						days[da] = <div className="c_empty" key={key+da}>&nbsp;</div>;
					}
				}
				weeks[mo][we] = <div className="week" key={key}>{days}</div>;
			}
		}

		return this.props.m1 || Util.anyMobile ?
		<div className="glass">
			<div
				className="calendar1m"
				style={this.props.leftTop}
				ref={ o => o && o.focus() }
				tabIndex="0"
				onKeyDown={this.keyHandler}
				onBlur={ (e) => this.props.setDate(0, e) }
			>
					<div className="month">
						<div className="c_month">{MONTHS[curMonth[1]] + ' ' + firstDayOfMonth[1].getFullYear()}</div>
						<div className="week">{DAYS}</div>
						{weeks[1]}
					</div>
<div className="c_arr c_left_arr"  onClick={ () => { this.changeCurDate( 0, -1,  0) }}>&#9668;</div>
<div className="c_arr c_right_arr" onClick={ () => { this.changeCurDate( 0,  1,  0) }}>&#9658;</div>
			</div>
		</div>
			:
		<div className="glass">
			<div
				className="calendar"
				style={this.props.leftTop}
				ref={ o => o && o.focus() }
				tabIndex="0"
				onKeyDown={this.keyHandler}
				onBlur={ (e) => this.props.setDate(0, e) }
			>
				<div className="quarter">
					<div className="month">
						<div>{MONTHS[curMonth[0]] + ' ' + firstDayOfMonth[0].getFullYear()}</div>
						<div className="week">{DAYS}</div>
						{weeks[0]}
					</div>
					<div className="month">
						<div className="c_month">{MONTHS[curMonth[1]] + ' ' + firstDayOfMonth[1].getFullYear()}</div>
						<div className="week">{DAYS}</div>
						{weeks[1]}
					</div>
					<div className="month">
						<div className="c_month">{MONTHS[curMonth[2]] + ' ' + firstDayOfMonth[2].getFullYear()}</div>
						<div className="week">{DAYS}</div>
						{weeks[2]}
					</div>
				</div>
<div className="c_arr c_left_arr"  onClick={ () => { this.changeCurDate( 0, -1,  0) }}>&#9668;</div>
<div className="c_arr c_right_arr" onClick={ () => { this.changeCurDate( 0,  1,  0) }}>&#9658;</div>
<div className="c_help">PgUp, PgDown - изменить месяц &nbsp; Home, End - начало, конец месяца<br/>Пробел - найти сегодня &nbsp; Enter - выбрать дату &nbsp; &nbsp;&nbsp;</div>
<div className="c_arr c_down_arr"  onClick={ () => { this.changeCurDate(-1,  0,  0) }}>&nbsp;&#9668;&nbsp;год&nbsp;</div>
<div className="c_arr c_up_arr"    onClick={ () => { this.changeCurDate( 1,  0,  0) }}>&nbsp;год&nbsp;&#9658;&nbsp;</div>
			</div>
		</div>;
	}
	//**********
}

export default Calendar;
