import React from 'react';
import autoBind from 'react-autobind';
import Document from '../Document';
import Util from './Util';
import SvFrame from '../fields/SvFrame';
import {boxing} from './boxing';

class DialogBox extends React.Component {
	state = { isOpen: false };

	constructor(props) {
		super(props);
		autoBind(this);
		this.offset = null;
	}

	getField = (xName, par) => Util.getField(this, xName, par);
	setField = (xName, par) => Util.setField(this, xName, par);
	setFocus = xName => Util.setFocus(this, xName);

	changeDropList = (xName, alias) => {
		let xn = xName.toUpperCase();
		this.register[xn] && this.register[xn].changeDropList && this.register[xn].changeDropList(alias);
	};

	inputBox = (label, text='', title='Ввод текста') => {
		if (this.state.isOpen)
			return;

		return new Promise((ok, cancel) => {
			this.show (
				title,
				{ D_TEXT: text }, // инициализация поля D_TEXT
				{	style: {width:500, height:230},
					buttons: ['Ввод+|Y', 'Отмена'],
					cmButton: _ => ok( this.getField('d_text') ),
					cmCancel: cancel,
				},
				{width:370, maxHeight:200},
				[	// описание секции flist
					[ { rowStyle: {width: 'auto'}}, Util.label(label, 0, {textAlign: 'left', padding: '30px 0 10px 5px'}) , ],
					[ { rowStyle: {width: '95%'}}, {field: ['D_TEXT', 'tx']} ]
				],
				'D_TEXT', // set focus
			)
		});
	};
	//**********

	showFields = (jsn) => {
		if (this.state.isOpen)
			return;

		let o = JSON.parse('{' + jsn.slice(0,-1) + '}');
		let ls = Object.keys(o).sort().map( (it, i) => { return (
			<div style={{padding: '5px 4px'}} key={i} >
				<div style={{fontWeight: 'bold', color: 'blue'}}>{it}</div>
				<div>{(o[it][0] || '').replace(/\n/g, '\\n') || '<empty>'}</div>
				<b><div>{(o[it][1] || '').replace(/\n/g, '\\n') || '<empty>'}</div></b>
			</div>);
		});
		let comp =
			<div style={{background: '#f8f8f8', font: 'normal 13px Courier', wordWrap: 'break-word'}}>
				{ls}
			</div>;

		return new Promise((yes_no, cancel) => this.show (
			'Просмотр измененных полей',
			comp,
			{	style: {width:800, height:500},
				buttons: ['Сохранить+|Y', 'Нет|N', 'Отмена'],
				cmButton: yes_no,	// в параметре функции передается строка 'Y' или 'N'
				cmCancel: cancel,
			},
			{width:670, maxHeight:470, overflow: 'auto'}
		));
	};
	//**********

	docPreview = (dbaUnid, parent) => {
		this.main = parent.props.main || parent;
		let [dba, unid] = Util.partition(dbaUnid, '&');
		if (this.state.isOpen)
			return alert('Нельзя открыть 2 диалоговых окна одновременно');


		let width = Math.min(this.main.width, 1120) - 10;
		let height = Math.min(this.main.height, 690) - 10;

		this.parent = parent;
		let layer = ( parent && parent.props.layer ) || 0;
		let st  = {
			style: {width:width, height:height },
			buttons: ['Закрыть+', 'Редактировать|e'],
			cmCancel: () => {},
			cmButton: () => Util.xopen('docopen?' + [dba, unid, 'edit'].join('&')),
		};
		let stD ={width:width-130, maxHeight:height-30, overflow: 'auto'};

		this.offset = {padding: `${layer*40}px 0 0 ${layer*40}px`};

		let doc =
			<Document
				key={unid}
				dbAlias={dba}
				unid={unid}
				rsMode="preview"
				preview={true}
				layer={layer+1}
				main={this.main}
			/>
		this.show ( 'Просмотр документа', doc, st, stD );
	};

//***********************
//***********************

	show(title, data, stDlg, stData, flist, setFocused, btnEnter, moreButtons, dlgButtons) {
		if ( this.state.isOpen ) {
			console.log('DialogBox.state.isOpen');
			return;
		}
		this.flist = null;
		this.dlgButtons = dlgButtons;
		if ( flist ) {
			this.flist = flist;
			this.setFocused = setFocused;
			this.register = {};
			this.hideNewValues = {};
			this.dumb = {};
			this.focusRows = [];
			this.currRow = 0;
			this.msg = this.props.doc.msg;
			this.sova = this.props.doc.sova.dialog || {};
			this.sova.init && this.sova.init(this);
			this.btnEnter = btnEnter;
			this.cmButton = stDlg.cmButton;
			this.fieldValues = {};
			data && Object.keys(data).forEach( k => this.fieldValues[k.toUpperCase()] = data[k] );
		}
		else {
			if ( typeof data === 'string') { // url для iframe
				let iStyle = {margin: '6px 0 0 6px', width: stData.width-8, height: (stData.heigh || stData.maxHeight )-8, border: 0, background: '#fff'};
				this.data = <SvFrame src={data} title={data} style={iStyle} load={ x => {this.iframe = x.refs.iframe} }/>;
				this.cmButton = x => stDlg.cmButton(x, this.iframe); // this.iframe нужен, чтобы запустить ifr.contentWindow.print() по кнопке "печать"
			}
			else {
				this.data = data;
				this.cmButton = stDlg.cmButton;
			}
		}
		this.title = title;
		this.cmCancel = stDlg.cmCancel;
		this.result = '';

		this.focusBt = null;
		let bts;
		if ( stDlg.buttons ) {
			bts = (stDlg.buttons || ['OK+|1']).map( (it, i) => {
				let focusBt = it.indexOf('+') >= 0;
				let ls = it.replace(/\+/g, '').split('|');
				if ( focusBt )
					this.result = ls[1] || '';

				return (
					<button
						key={i}
						tabIndex={(i+100).toString()}
						onClick={ _ => this.btnClick(ls[1] || '') }
						onFocus={ _ => this.result = ls[1] || '' }
						onBlur={ _ => this.result = '' }
						ref={ o => {if (focusBt) this.focusBt = o }}
					>
						{ls[0]}
					</button>
				);
			});

			let more = null;
			if (moreButtons) {
				more = <div key={Math.random()}>{boxing(moreButtons, this)[0]}</div>
			}
			this.buttons =
				<div className={moreButtons ? 'moreButtons' : (this.dlgButtons || 'dlgButtons')}>
					{bts}
					{more}
				</div>
		}
		else {
			this.buttons = null;
		}
		this.setState ( { dlgDivStyle: {...stDlg.style}, isOpen: true, dlgDataStyle: {...stData} });
	}
	//**********

	componentDidUpdate(prevp, prevs) {
		this.setFocused ?
			this.register[this.setFocused].setFocus()
			:
			this.focusBt && this.focusBt.focus();
	}
	//**********
	btnClick(s) {
		this.setFocused = null;
		this.setState ( {isOpen: false} );
		this.parent && this.parent.setFocus(this.parent.focus)

		if ( s && this.cmButton ) {
			this.cmButton(s);
		}
		else if ( !s && this.cmCancel ) {
			this.cmCancel();
		}
	 }
	 //**********

	 onkeydown(event) {
		switch (event.keyCode) {
			case 27:	this.btnClick(null);
				break;
			case 13:
				if (event.shiftKey)
					return;
				if (this.btnEnter && this.btnEnter in this.register) {
					event.preventDefault();
					this.register[this.btnEnter].props.btnClick();
				}
				else {
					this.btnClick(this.result || 1);
				}
				break;
			default:
				if ( !(event.ctrlKey || event.altKey) )
					return;
		}
		event.stopPropagation();
	}
	 //**********

	render() {
		if ( ! this.state.isOpen )
			return null;

		if (this.flist) {
			let table = this.flist.map( (row, i) => {
				let ls = boxing(row, this); // ls[0] - массив меток-полей-кнопок в одной строке, ls[1] style строки, ls[2] className строки
				return <div className={ls[2] || "row"} key={i} style={{...ls[1]}}>{ls[0]}</div>;
			});
			this.data = <div>{table}</div>;
		}
		return (
			<div className="dlgBG" style={ this.offset ? {position: 'fixed', zIndex: 500 + this.layer} : {zIndex: 500} }>
				<div onFocus={ _ => this.btnClick('') } tabIndex="1">
				<div style={this.offset} onFocus={ _ => this.btnClick('') } tabIndex="1">
					<div className="dlgDiv" style={this.state.dlgDivStyle} onKeyDown={this.onkeydown} tabIndex="1" onFocus={ e => e.stopPropagation() }>
						<div className="dlgTitleBar">
							{this.title}
							<div className="dlgCloseButton" title="Закрыть" onClick={ _ => this.btnClick('') } >&times;</div>
						</div>
						<div style={{display: 'block', width: '100%', overflow: 'hidden'}}>
							<div style={{...this.state.dlgDataStyle, display: 'inline-block'}}>
								{this.data}
							</div>
							{this.buttons}
						 </div>
					</div>
				</div>
				</div>
			</div>
		);
	}
	//**************

};
//***********************
export default DialogBox
