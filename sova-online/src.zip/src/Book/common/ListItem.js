import React from 'react';

class ListItem extends React.Component {
	constructor(props) {
		super(props);

		let st = !this.props.sel && this.props.iShow % 2 && !this.props.evenColor ? {background: '#f4f8ff'} : {};
		if ( this.props.multi && this.props.check ) {
			st.fontWeight = 'bold';
			if ( !this.props.sel)
				st.color = '#00f';
		}
		this.state = { style: {...st}};
	}

	onclick = e => this.props.toggle(this.props.index, e);
	ondubleclick = e => {e.stopPropagation(); e.preventDefault();};

	render() {
		let chb = !this.props.multi ?
			null
			:
			<span
				className={'multi'}
				onClick={this.onclick}
				onDoubleClick={this.ondubleclick}
			>
				{this.props.check ? '\u2228' : '\u00a0'}
			</span>;

		let cn = this.props.listItemClassName || 'listItem';
		if ( this.props.sel )
			cn += ' ' + (this.props.listItemSelClassName || 'listItemSel');

		let st = {...this.state.style};
		if (this.props.sel)
			delete st.background;
		return (
			<div
				className={cn}
				ref={o => this.div = o}
				tabIndex="0"
				onClick={ _ => this.props.onclick(this.props.iShow) }
				onDoubleClick={_ => this.props.ondoubleclick(true)}
				onMouseOver={_ => !this.props.sel && this.props.evenColor && this.setState({ style: {background: '#f0f4ff'} }) }
				onMouseOut={_ =>  !this.props.sel && this.props.evenColor && this.setState({ style: {background: '#fff'} }) }
				style={st}
			>
				{chb}
				{this.props.items[this.props.index].label}
			</div>);

	}
}

export default ListItem
