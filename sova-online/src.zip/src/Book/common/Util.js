//***********************
//
//***********************
import React from 'react';

// *** *** ***
// from www.npmjs.com/package/ismobilejs
let isMobile = (_ => {
    if (!window.navigator)
            return;
    const f=/iPhone/i,j=/iPod/i,p=/iPad/i,g=/\bAndroid(?:.+)Mobile\b/i,i=/Android/i,d=/\bAndroid(?:.+)SD4930UR\b/i,e=/\bAndroid(?:.+)(?:KF[A-Z]{2,4})\b/i,c=/Windows Phone/i,h=/\bWindows(?:.+)ARM\b/i,k=/BlackBerry/i,l=/BB10/i,m=/Opera Mini/i,n=/\b(CriOS|Chrome)(?:.+)Mobile/i,o=/Mobile(?:.+)Firefox\b/i;
    const b = ($,a) => $.test(a);
    let $ = navigator.userAgent;
    let a = $.split("[FBAN");
    a[1] && ($=a[0]);
    (a=$.split("Twitter"))[1] && ($=a[0]);
    let r={
        apple:{phone:b(f,$)&&!b(c,$),ipod:b(j,$),tablet:!b(f,$)&&b(p,$)&&!b(c,$),device:(b(f,$)||b(j,$)||b(p,$))&&!b(c,$)},
        amazon:{phone:b(d,$),tablet:!b(d,$)&&b(e,$),device:b(d,$)||b(e,$)},
        android:{phone: (!b(c,$)&&b(d,$)) || (!b(c,$)&&b(g,$)),
        tablet:!b(c,$)&&!b(d,$)&&!b(g,$)&&(b(e,$)||b(i,$)),
        device:!b(c,$)&&(b(d,$)||b(e,$)||b(g,$)||b(i,$))},
        windows:{phone:b(c,$),tablet:b(h,$),device:b(c,$)||b(h,$)},
        other:{blackberry:b(k,$),blackberry10:b(l,$),opera:b(m,$),firefox:b(o,$),chrome:b(n,$),device:b(k,$)||b(l,$)||b(m,$)||b(o,$)||b(n,$)},any:!1,phone:!1,tablet:!1
    };
    r.any=r.apple.device||r.android.device||r.windows.device||r.other.device;
    r.phone=r.apple.phone||r.android.phone||r.windows.phone;
    r.tablet=r.apple.tablet||r.android.tablet||r.windows.tablet;
    return r;
})();


export const common = {
	recalc: {
		CCTYPE: (doc, newValue, alias) => {
			if ( alias ) {
				let ls = alias.split('|');
				doc.setField('CCTYPE_ALIAS', ls[0]);
				let days = parseInt(ls[1], 10);
				if ( !isNaN(days) ) {
					let da = doc.getField('DOCDA');
					da = da ? new Date(da + ' 00:00:00') : new Date();

					// doc.setField('CCDA', new Date( da.valueOf() + 1000*60*60*24*days ));
					// при попадании на субботу или воскресенье меняется срок на пятницу.

					let newdate = new Date( da.valueOf() + 1000*60*60*24*days );
					if (newdate.getUTCDay() === 0) // sunday
						newdate = new Date( newdate.valueOf() - 1000*60*60*24*2 );
					else if (newdate.getUTCDay() === 6) // saturday
						newdate = new Date( newdate.valueOf() - 1000*60*60*24*1 );
					doc.setField('CCDA', newdate);
				}
				else
					doc.setField('CCDA', '');
			}
			else {
				doc.setField('CCTYPE_ALIAS', '');
				doc.setField('CCDA', '');
			}
		}
	},
};
// *** *** ***

const setColor = (s, disable) => {
	if ( disable )
		return s;

	let box;
	let re = /<<[\s\S]+?>>/g;
	let m = s.match(re);
	if ( !m )
		return s;

	let ls =  s.split(re); // массив текстов между элементами
	box = [ ls[0] || null ];

	m.forEach( (it, i) => {
		let item;
		let style;
		switch (it[2]) {
			case 'R': style = {color: 'red'}; break;
			case 'G': style = {color: 'green'}; break;
			case 'B': style = {color: 'blue'}; break;
			case 'W': style = {color: 'white}'}; break;
			case 'C': style = {}; break;
			default:  item = it;
		}
		if ( !item ) {
			if ( it[3] === '+' )
				style.fontWeight = 'bold';
			item = <span key={i} style={style}>{it.slice(4, -2)}</span>;
		}
		box.push(item); // элемент
		if ( ls[i+1] )  //текст после элемента
			box.push(ls[i+1]);
	});
	return box;
}
// *** *** ***

let wins = {};

export const Util = {
	isMobile: isMobile,
	anyMobile: isMobile.any,

	getField : (doc, xName, par) => {
		let xn = xName.toUpperCase().trim();
		let xv = xn in doc.register && doc.register[xn].getValue ?
			doc.register[xn].getValue(par)
			:
			(xn in doc.hideNewValues ? doc.hideNewValues[xn] : doc.fieldValues[xn]);
		return par === 'list' ? xv : (xv || '').replace(/¤/g, '\n'); //_
	},

	setField : (doc, xName, xValue, par) => {
		let xn = xName.toUpperCase();
		let xv = (typeof xValue) === 'string' ? xValue.replace(/¤/g, '\n') : xValue;
		if ( xn in doc.register && doc.register[xn].setValue )
			doc.register[xn].setValue(xv, par);
		else
			doc.hideNewValues[xn] = xv;
	},

	setFocus: (doc, xName) => {
		let xn;
		if ( typeof xName === 'number' )
			xn =  doc.focusRows[ Math.max(0, Math.min(xName, doc.focusRows.length-1) ) ];
		else {
			if ( !xName )
				return;
			xn = xName.toUpperCase();
		}
		if (xn && doc.register[xn] && doc.register[xn].setFocus && !doc.register[xn].props.readOnly)
		 	doc.register[xn].setFocus();
		else {
			xn = doc.focusRows && doc.focusRows[0];
			if (xn && doc.register[xn] && doc.register[xn].setFocus && !doc.register[xn].props.readOnly)
				doc.register[xn].setFocus();
		}
	},

	xopen: url => {
		if ( url in wins && !wins[url].closed )
			/Firefox/.test(navigator.userAgent) ? wins[url].alert('Окно уже открыто') : wins[url].focus();
		else
			wins[url] = window.open(url);
	},

	serverAction: (doc, s) => new Promise( (yes, no) => {
		let par = {
			credentials: 'include',
			method: 'post',
			headers: { 'Content-type': 'text/plain; charset=UTF-8' },
			body: s,
		};
		doc.waitSave = true;
		doc.setState({spinner: true});
		fetch( 'action', par )
			.then( response => {
				doc.waitSave = false;
				doc.setState({spinner: false});
				response.status === 200 ?
					yes(response)
				:
					response.text().then( tx => no(tx) );
			})
			.catch( err => {
				doc.waitSave = false;
				doc.setState({spinner: false});
				no(err.message);
			});
	}),
	// *** *** ***

	upDown: (e, clr=true) => {
		if ( (e.keyCode === 38) && !(e.altKey || e.shiftKey || e.ctrlKey) ) {
			if ( clr ) {
				e.stopPropagation();
				e.preventDefault();
			}
			return 'up';
		}
		if ( (e.keyCode === 40) && !(e.altKey || e.shiftKey || e.ctrlKey) ) {
			if ( clr ) {
				e.stopPropagation();
				e.preventDefault();
			}
			return 'down';
		}
	},

	// *** *** ***

	recalc: (fi, newValue='', alias='', i=-1) => { //номер в списке в поле List
		let doc = fi.props.doc;
		let xName = fi.props.xName;
		( common.recalc[xName] && (setTimeout( _ => common.recalc[xName](doc, newValue, alias, i), 10) || true) )
		|| (
			doc.sova.recalc &&
			doc.sova.recalc[xName] &&
			setTimeout( _ => doc.sova.recalc[xName](doc, newValue, alias, i), 10) );
	},
	// *** *** ***

	runCmd: (doc, cmd, param, ctrl) => {
		return doc.sova && doc.sova.cmd && doc.sova.cmd[cmd] ?
			doc.sova.cmd[cmd](doc, param, ctrl)
			:
			doc.cmdList && doc.cmdList[cmd] && doc.cmdList[cmd](param, ctrl);
	},
	// *** *** ***
	_on_: props => {
		if ( !props || Object.keys(props).length < 2)
			return null;

		let on = {};
		Object.keys(props).forEach ( it => {
			if ( it.startsWith('on') ) {// onBlur etc
				let [cmd, param] = Util.partition(props[it], '|');
				on[it] = e => {
					e.preventDefault();
					e.stopPropagation();
					Util.runCmd(props.doc, cmd, param);
				}
			}
		});
		return on;
	},
	// *** *** ***

	hide: (doc, name) => name && doc.sova.hide && doc.sova.hide[name] && doc.sova.hide[name](doc),
	readOnly: (doc, name) => name && doc.sova.readOnly && doc.sova.readOnly[name] && doc.sova.readOnly[name](doc),

	// *** *** ***

	label: (lb, w, st) => {
		let lab = lb || '\u00a0';
		if (st)
			return w ? { div: lab, style: {...st, width: w}, className: 'label' } : { div: lab, style: {...st}, className: 'label' };
		else
			return w ? { div: lab, style: {width: w}, className: 'label' } : { div: lab, className: 'label' };
	},

	// *** *** ***

	partition: (s, sep) => {
		if (s) {
			let ls = s.split(sep);
			return ls.length > 1 ? [ls[0].trim(), ls.slice(1).join(sep).trim()] : [s.trim(), ''];
		}
		return ['',''];
	},
	// *** *** ***

	dtRus: val => {
		let ls = (val || '').split('\n').map ( s => { //_
			if ( typeof s !== 'string' )
				return '';

			if ( s.indexOf('-') < 0)
				return s;

			let [dt, tm] = Util.partition(s, ' ');
			return dt.slice(-2) + '.' + dt.slice(5,7) + '.' + dt.slice(0,4) + (tm ? ' ' + tm : '');
		});
		return ls.join('\n'); //_
	},
	// *** *** ***

	dtDB: val => {
		let ls = val.split('\n').map ( s => { //_
			if ( typeof s !== 'string' )
				return '';

			if ( s.indexOf('.') < 0)
				return s;

			let [dt, tm] = Util.partition(s, ' ');
			return dt.slice(-4) + '-' + dt.slice(3,5) + '-' + dt.slice(0,2) + (tm ? ' ' + tm : '');
		});
		return ls.join('\n'); //_
	},
	// *** *** ***

	formatDate: dt =>
		('0' + dt.getUTCDate()).slice(-2) + '.' + ('0' + (dt.getUTCMonth()+1)).slice(-2) + '.' + dt.getUTCFullYear(),

	// *** *** ***

	formatDateTime: dt =>
		dt.getFullYear() + '-' + ('0' + (dt.getMonth()+1)).slice(-2) + '-' + ('0' + dt.getDate()).slice(-2) + ' ' + ('0' + dt.getHours()).slice(-2) + ':' + ('0' + dt.getMinutes()).slice(-2) + ':' + ('0' + dt.getSeconds()).slice(-2),

	// *** *** ***

	addJson: (fi, oldv, newv) => {
		let nw = newv || '';
		if ( window.SOVA_SEP )
			nw = nw.replace(/\n/g, '¤');
		return (oldv || '') === nw || fi.endsWith('_FD') || fi.endsWith('.FD') ? // .FD _FD - for display
			''
			:
			'"' + fi + '":[' + JSON.stringify(oldv || '') + ',' + JSON.stringify(nw) + '],';
	},
	// *** *** ***

	jsonByUrl: (url, method='get', body=null) => new Promise( (yes, no) => {
		let par = {credentials: 'include'};
		if (  method === 'get' ) {
			par.cache = url.startsWith('api.getc?') || url.startsWith('list?') ? 'force-cache' : 'no-store';
		}
		else {
			par.method = 'post';
			par.headers = { 'Content-type': 'text/plain; charset=UTF-8' };
			par.body = body;
		}
		fetch( url, par )
			.then( response => response.status === 200 ?
				response.json()
				:
				no('jsonByUrl.js.fetch-status: ' + response.status)
			)
			.then( jsn => yes(jsn) )
			.catch(err => {
				console.error('jsonByUrl.js.fetch-error:', err.message);
				no(err.message);
			});
	}),
	// *** *** ***
	jsCssFiles: [],

	addJsCSS: (lsf, f) => {
		if (!lsf)
			return f();

		let ls = [];
		lsf.forEach (it => {
			if ( it && !Util.jsCssFiles.includes(it) ) {
				ls.push(it);
				Util.jsCssFiles.push(it);
			}
		});
		if (!ls.length)
			return f();

		let i = 0;
		let oneLink = _ => {
			let link;
			if (Util.partition(ls[i], '::')[0].endsWith('.css')) {
				link = document.createElement('link');
				link.rel = 'stylesheet';
				link.href = ls[i];
			}
			else {
				link = document.createElement('script');
				link.src = ls[i];
			}
			if (window.owlDebug)
				console.log('include', link.rel || 'script', ls[i]);
			document.head.appendChild(link);
			i++;
			link.onload  = _ => i >= ls.length ? f() : oneLink();
			link.onerror = _ => i >= ls.length ? f() : oneLink();
		};
		oneLink();
	},
	// *** *** ***

	cmpObj: (o1, o2) => {
		if ( typeof o1 === 'undefined' && typeof o2 === 'undefined' )
			return true;
		if ( typeof o1 !== typeof o2 )
			return false;

		for (let p in o1) {
			if ( o1.hasOwnProperty(p) !== o2.hasOwnProperty(p) ) {
				return false;
			}
			if ( typeof o1[p] === 'object' ) {
				if ( !Util.cmpObj(o1[p], o2[p]) )
					return false;
			}
			else if ( o1[p] !== o2[p] )
				return false;
		}
		for (let p in o2) {
			if ( typeof (o1[p]) === 'undefined' )
				return false;
		}
		return true;
	},

	splitText: (text, attr) => {
		if ( !text )
			return null;
		if ( text.includes('\n') && attr.br )
				return text.split('\n').map( (it, ii) => {
					if ( attr.s2 && ii === attr.s2-1 )
						return attr.br === 'p' && it ?
							<p key={ii}><b>{setColor(it)}</b></p>
							:
							<span key={ii}><b>{ii ? <br/> : null}{setColor(it)}</b></span>;
					else
						return attr.br === 'p' && it ?
							<p key={ii}>{setColor(it)}</p>
							:
							<span key={ii}>{ii ? <br/> : null}{setColor(it)}</span>;
				});
		else
			return attr.s2 === 1 ? <b>{setColor(text)}</b> : setColor(text);
	},
	// *** *** ***

};
// *** *** ***

export default Util;
