import React from 'react';

import Text from '../fields/Text';
import List from '../fields/List';
import ListBox from '../fields/ListBox';
import Datepicker from '../fields/Datepicker';
import ForDisplayOnly from '../fields/ForDisplayOnly';
import Table from '../fields/Table';
import Schedule from '../fields/Schedule';
import {Checkbox, Checkbox3} from '../fields/Checkbox';
import ReadyList from '../fields/ReadyList';
import View from '../fields/View';
import RTF from '../fields/RTF';
import JsonArea from '../fields/JsonArea';
import Svg from '../fields/Svg';
import Utils from './Util';


export const focusedTypes = ['lbsd','lbse','lbmd','lbme','dt','tx']; //  поля с фокусом

export const controller = prop => {
	switch (prop.type) { //тип поля
		case 'chb3':	return <Checkbox3 {...prop}/>;
		case 'chb':		return <Checkbox {...prop}/>;
		case 'lbse':
		case 'lbme':
		case 'tx':		return <Text {...prop}/>;
		case 'lbsd':
		case 'lbmd':	return <ListBox {...prop}/>;
		case 'dt':		return (prop.readOnly ?
							<Text {...prop} xValue={Utils.dtRus(prop.xValue)} />
							:
							<Datepicker {...prop}/>);
		case 'fd_p':
		case 'fd_ol':
		case 'fd_ul':
		case 'fd':		return <ForDisplayOnly {...prop}/>;
		case 'table':
		case 'gr':		return <Table {...prop}/>;
		case 'rtf':		return <RTF {...prop}/>;
		case 'json':	return <JsonArea {...prop}/>;
		case 'list':	return <List {...prop}/>;
		case 'readyList':	return <ReadyList {...prop}/>;
		case 'view':	return <View {...prop}/>;
		case 'svg':		return <Svg {...prop}/>;
		case 'sch':		return <Schedule {...prop}/>;

		default:
			console.warn('Неизвестный тип поля', prop.xName, prop.type);
			return <Text {...prop}/>;
	}
};
