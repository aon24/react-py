import React from 'react';

import FileShow from '../fields/FileShow';
import SvFrame from '../fields/SvFrame';
import Button from '../fields/Button';
import {rtf} from '../fields/RTF';
import Util from './Util';
import {controller, focusedTypes} from './controllers';
import {SvgElement} from '../fields/Svg';

// *** *** ***

class Dumb extends React.Component {
	constructor(props) {
		super(props);
		this.state = {value: this.props.xValue};
	}
	setValue = value => this.setState({value: value});
	render = _ => this.state.value;
}
// *** *** ***

export const makeControl = (i, td, doc, readOnly, hide, wl) => { // wl - шириина метки по умолчанию
	let register = doc.register;
	let style = td.attributes ? {...td.attributes.style} : {...td.style};
	let name = td.attributes ? td.attributes.name : td.name;
	readOnly = readOnly || (td.attributes ? td.attributes.readOnly : td.readOnly) || Util.readOnly(doc, name);

	if ( Util.hide(doc, name) )
		style.display = 'none';

	if ( style.width ) {
		style.maxWidth = style.maxWidth || style.width;
		style.minWidth = style.minWidth || style.width;
	}

	if ( td._teg ) {
		if ( td._teg.toLowerCase() === 'svg' )
			return <SvgElement key={i} doc={doc} _teg="svg" attributes={td.attributes} children={td.children}/>;

		let attr = td.attributes || {};
		let className = attr.className || '';
		let text = Util.splitText(td.text, attr);
		let children, ls;
		if ( td.children ) {
			ls = boxing(td.children, doc, readOnly, hide || style.display === 'none', attr.wl || wl);
			if (ls && ls.length) {
				children = ls[0];
				style = {...style, ...ls[1]};
				className = (className + ' ' + (ls[2] || '') ).trim();
			}
		}
		switch ( td._teg.toLowerCase() ) {
			case 'div':
				if ( attr.className && attr.className.startsWith('label') && !style.width && wl)
					style.width = style.minWidth = style.maxWidth = wl;
				return <div key={i} id={attr.id} className={className} style={style}>{text}{children}</div>;
			case 'a': return <a
					href={attr.href}
					id={attr.id}
					name={name}
					target={attr.target}
					title={attr.title}
					className={attr.className}
					style={style}
					key={i}
				>{text}{children}</a>;

			case 'img':
				let img = <img src={attr.src} width="100%" alt="alt" title={attr.title} className={attr.className} style={style} key={'i' + i}/>;
				if (attr.href)
					return <a href={attr.href} key={i} target={attr.target} title={attr.title}>{img}{td.text}</a>;
				else if (attr.cmd)
					return <div onClick={_ => Util.runCmd(doc, attr.cmd, attr.param)} key={i} title={attr.title} style={{cursor: 'pointer'}}>{img}{td.text}</div>;
				else
					return img;

			case 'button':
				if (td._div) {
					let btn = 'BTN_' + td._cmd.toUpperCase();
					return	<Button
								key={i}
								label={td.text}
								cmd={td._cmd}
								param={td._param}
								doc={doc}
								{...attr}
								style={style}
								ref={ o => { if (o && !register[btn]) register[btn] = o } }
							/>;
				}
				return 	<button
							key={i}
							{...attr}
							onClick={ e => Util.runCmd(doc, td._cmd, td._param, e.ctrlKey) }
						>{td.text}</button>;

			case 'ul':
				ls = text ? text.split('\n').map( (it, ii) => <li key={ii}>it</li> ) : null;
				return <ul key={i} {...attr}>{ls}</ul>;
			case 'ol':
				ls = text ? text.split('\n').map( (it, ii) => <li key={ii}>it</li> ) : null;
				return <ol key={i} {...attr}>{ls}</ol>;

			case 'input': return <input key={i} {...attr}/>;
			case 'form': return <form key={i} {...attr}>{text}{children}</form>;
			case 'textarea': return <textarea key={i} {...attr}>{text}</textarea>;
			case 'label': return <label key={i} {...attr}>{text}{children}</label>;
			case 'b': return <b key={i} {...attr}>{text}{children}</b>;
			case 'i': return <i key={i} {...attr}>{text}{children}</i>;
			case 'p': return <p key={i} {...attr}>{text}{children}</p>;
			case 'span': return <span key={i} {...attr}>{text}{children}</span>;
			case 'br': return <br key={i}/>;

			default:
				console.log('undefined _teg:', td._teg);
		}
		return null;
	}
	// ***

	if (td.field) {
		let xName = td.field[0].toUpperCase();
		let xValue = (doc.fieldValues && doc.fieldValues[xName]) || '';
		if ( typeof xValue !== 'string' )
			return;

		let prop = {
			...td,
			key: i,
			doc: doc,
			xName: xName,
			xValue: xValue.replace(/¤/g, '\n'),
			readOnly: readOnly && !td.edit,
			type: td.field[1],
			ls: td.field[2] || null,
			ref: o => { register[xName] = o },
			style: style,
		};
		if ( focusedTypes.includes(prop.type) && !prop.readOnly ) // данный ряд содержит поле с фокусом
			prop.myRow = doc.currRow;

		return controller(prop);
	}

	if ( td.fileShow ) {// todo: задать ф-ш, в которое будут перетаскиваться файлы мышкой
		let tdp = {...td, style: style, readOnly: readOnly && !td.edit };
		return (
			<FileShow
				key={i}
				doc={doc}
				{...tdp}
				uploadDone={doc.cmdSave2}
				ref={ o => doc.fileShow[td.fileShow] = o }
			/>
		);
	}

	if ( td.rtf ) {
		let box = rtf(td.rtf, doc, readOnly, wl);
		return box ?
			<div className={td.className} style={style} key={i}>{box}</div>
			:
			null;
	}

	if ( td.video ) {
		let propsV = {};
		for (let k in td){
			if (k !== 'video')
				propsV[k] = td[k];
		}
		return <video key={i} {...propsV} ref={ o => doc.register[td.video] = o }/>;
	}

	if ( td.iframe ) {
		name = (name || 'iframe').toUpperCase();
		let tdp = {...td, style: style, name: name};
		return <SvFrame key={i} {...tdp} src={td.iframe.trim()} ref={ o => doc.register[name] = o }/>;
	}

	if ( typeof td.div === 'string' )	// для совместимости с раскраской в rtf полях в документации
		return <div key={i} style={{...td.style}} className={td.className}>{td.div}</div>;

	console.log('empty element: ', td);
	return null;
}
// *** *** ***

export const boxing = (row, doc, readOnly, hide, wl, kkey) => {
	if ( !row )
		return [];

	let rowStyle = {};
	let rowClassName = '';

	let isField;
	let r = row.map( (td, i) => {
		if ( !(td && typeof td === 'object') )
			return null;

		if (td.rowStyle || td.rowClassName) { //служебный контрол для свойств ряда
			rowStyle = td.rowStyle || rowStyle;
			rowClassName = td.rowClassName || rowClassName;
			return null;
		}

		if ( td.dumb ) return ( // используется в диалогах, например для вкючения спиннера
			<Dumb
				key={i}
				xValue={td.xValue} // компонента реакт
				ref={ o => doc.dumb[td.dumb] = o }
			/>);

		// если данный ряд содержит поле с фокусом, запомнить имя первого поля ряда
		let name = td.attributes ? td.attributes.name : td.name;
		if ( !(readOnly || td.readOnly || Util.readOnly(doc, name) ) )
			if ( !isField && td.field && focusedTypes.includes(td.field[1]) )
					isField = td.field[0];

		return makeControl(kkey || i, td, doc, readOnly, hide, wl);
	});

	if ( isField && !hide )
		doc.focusRows[doc.currRow++] = isField;

	return [r.filter(it => it), rowStyle, rowClassName];
};
// *** *** ***
