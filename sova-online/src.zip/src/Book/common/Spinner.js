import React from 'react';

export const spinner = (fullScreen, oldSpinner, preloaderColor='') => {
	let spin = oldSpinner ?
		<div className="spinner"/> // - старая версия (яйцо)
		:
		<div className={'preloader ' + preloaderColor}>
			<div/>
			<div/>
			<div/>
			<div/>
			<div/>
			<div/>
			<div/>
			<div/>
			<div/>
			<div/>
		</div>;
	return fullScreen ? <div className="spinner-wrap">{spin}</div> : spin;
}

// <div className="spinner-wrap"><div className="spinner"/></div> // - старая версия
