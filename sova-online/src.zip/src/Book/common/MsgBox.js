import React from 'react';
import autoBind from 'react-autobind';
import ListItem from './ListItem';
import Util from './Util';

class MsgBox extends React.Component {
	state = { isOpen: false, sel: 0, };
	clearState = {
		dlgDivStyle: {width: '600px', height: '400px'},
		sel: 0,
	};
	// *** *** ***
	constructor(props) {
		super(props);
		autoBind(this);
		this.input = null;
	}
	// *** *** ***

	// yesNo: buttons: ['Да+|Y', 'Нет']
	// yesNoCancel: buttons: ['Да+|Y', 'Нет|N','Отмена']
	// yesNoShowCancel:  ['Сохранить+|Y', 'Нет|N', 'Изменения|S', 'Отмена']

	box = (text, title='Sova.online', buttons=['OK+|Y'], style=null) => new Promise((ok, cancel) => this.show (
		title,
		text,
		{	buttons: buttons,
			cmCancel: cancel,
			cmButton: ok,	// в параметре функции передается строка 'Y' или 'N' или 'S'
			dlgDataStyle: style,
		})
	);

	error = (text, title='Ошибка') => this && !this.state.isOpen ?
			this.show ( title, text, {type: 'Error'} )
			:
			alert(title + ': ' + text);

	list = (list, title='Выберите значение', sd={}, small) => new Promise((select, cancel) => this.show ( title, list, {
			lb: true,
			multi: sd.multi || false,
			checked: sd.checked || null,
			text: sd.text || null,
			sep: sd.sep || '|',
			buttons: ['ОК (Enter)+|1', 'Отмена (Esc)'],
			cmCancel: cancel,
			cmButton: select,	// в параметре функции передается выбранное значение
			dlgDivStyle: small ? {width: 440, height: 300, backgroundImage: 'url(/image?24x24LB.png)'} : {width: 740, height: 500, backgroundImage: 'url(/image?24x24LB.png)'},
			dlgDataStyle: small ? {width: 310, height: 220} : null,
		})
	);

	//**********
	//**********
	//**********

	show(title, data, st) {
		if ( this.state.isOpen ) {
			console.log('MsgBox.state.isOpen');
			return;
		}
		[this.title, this.header] = title.split('|');
		this.cmCancel = st.cmCancel;
		this.cmButton = st.cmButton;
		this.lb = st.lb;	// listBox
		this.multi = st.multi;
		this.checked = st.checked || [];
		this.result = '';

		if (this.lb) {
			this.sep = st.sep || '|';
			this.text = st.text;
			this.mainSel = -1;
			this.items = [];
			data.forEach( (it, i) => {
				let [left, right] = Util.partition(it, this.sep);
				this.items[i] = {ref: null, label: left, opt: right};
			});
			this.setFilter(this.text);
		}
		else
			this.items = data.split('\n');

		this.focusBt = null;
		this.buttons = (st.buttons || ['OK+|1']).map( (it, i) => {
			let focusBt = it.indexOf('+') >= 0;
			let ls = it.replace(/\+/g, '').split('|');
			if ( focusBt )
				this.result = ls[1] || '';

			return (
				<button
					key={i}
					tabIndex="1"
					style={{width: '105px', marginBottom: '10px'}}
					onClick={ () => this.btnClick(ls[1]) }
					onFocus={ _ => this.result = ls[1] || '' }
					onBlur={ _ => this.result = '' }
					ref={ o => { if (focusBt) this.focusBt = o }}
				>
					{ls[0]}
				</button>
			);
		});
		this.setState ( {...this.clearState, dlgDivStyle:st.dlgDivStyle, dlgDataStyle:st.dlgDataStyle, isOpen: true, sel: this.checked[0] || 0} );
		setTimeout( _ => {
			if ( this.lb && this.input ) {
				this.items[this.state.sel] && this.items[this.state.sel].ref && this.items[this.state.sel].ref.div.focus();
				this.input.focus();
			}
		}, 50);
	}
	//**********

	componentDidUpdate(prevp, prevs) {
		if ( this.input && this.text)
			this.input.value = this.text;

		this.lb ?
			setTimeout( _ => this.input && this.input.focus(), 50 )
			:
			this.focusBt && this.focusBt.focus();
	}
	//**********

	btnClick(s) {
		this.setState ( {isOpen: false} );

		if ( s && this.cmButton ) {
			if ( this.lb ) {
				if (this.items.length) {
					if ( this.multi ) {
						let ls = this.checked.filter( it => it !== undefined );
						ls = ls.map( it => this.items[it].label + (this.items[it].opt ? this.sep + this.items[it].opt : '') );
						this.cmButton(ls.join('\n')); //_
					}
					else {
						let opt = this.items[this.mainSel].opt ? this.sep + this.items[this.mainSel].opt : '';
						this.cmButton(this.items[this.mainSel].label + opt);
					}
				}
				else {
					this.cmButton('');
				}
			}
			else
				this.cmButton(s);
		}
		else
			!s && this.cmCancel && this.cmCancel();

		this.lb = this.checked = this.filtered = this.items = null;
	 }
	 //**********

	 onkeydown(event) {
 		if (event.ctrlKey)
 			return;

		if ( event.keyCode === 13 || event.keyCode === 27 ) {
			this.btnClick( event.keyCode === 13 ? (this.result || this.lb) : null);
			event.stopPropagation();
			event.preventDefault();
			return;
		}
		if ( !this.lb )
			return;

		let i = 0;
		switch(event.keyCode) {
			case 32:
				return this.toggle(this.mainSel, event);
			case 38:
				if ( this.state.sel )
					i = this.state.sel - 1;
				break;
			case 40:
				i = Math.min(this.last, this.state.sel + 1);
				break;
			case 33:	// pageUp
				i = Math.max(0, this.state.sel - 10);
				break;
			case 34:
				i = Math.min(this.last, this.state.sel + 10);
				break;
			case 36:
				if ( event.ctrlKey )
					break;
				return;
			case 35:
				if ( event.ctrlKey ) {
					i = this.last;
					break;
				}
				return;
			case 9:
				i = this.state.sel;
				break;
			default:
				if ( !(event.ctrlKey || event.altKey) )
					return;
		}
        event.stopPropagation();
        event.preventDefault();
		let k = this.filtered && this.filtered[i] ? this.filtered[i].ref.props.index : i;
		this.items[k] && this.items[k].ref && this.items[k].ref.div.focus();
		this.setState({sel: i});
		setTimeout( _ => this.input && this.input.focus(), 50 );
    }
	 //**********

	 onchange(event) {
		 this.text = event.target.value;
		 this.setFilter(this.text);
		 this.setState({sel: 0});
	 }
	 //**********

	 setFilter(text) {
		 this.filtered = null;
		 if ( text ) {
		 	let sep = ' («"\'-';
			let txl = text.toLowerCase();
			this.filtered = this.items.filter( it => {
				for ( let ch of sep ) {
					if ( (ch + it.label).toLowerCase().includes(ch + txl) )
						return true;
				}
				return false;
			});
		}
	 }
	 //**********

	 onclick (i) {
		this.setState({sel: i});
		setTimeout( _ => this.input && this.input.focus(), 50 );
	}
	 //**********

	 toggle (index, event) {
		if ( this.multi ) {
			this.filtered = null;
			this.input.value = '';
			this.text = '';

			let k = this.checked.indexOf(index);
			if ( k >= 0)
				delete this.checked[k];
			else
				this.checked.push(index);

			this.setState({sel: index});
			setTimeout( _ => this.items[index] && this.items[index].ref && this.items[index].ref.div.focus(), 100);
			setTimeout( _ => this.input && this.input.focus(), 150 );
		}
		event.stopPropagation();
		event.preventDefault();
	 }
	 //**********

	render() {
		if ( ! this.state.isOpen )
			return null;
		this.last = -1;
		this.mainSel = 1;
		let list = this.items.map( (it, i) => {
			if ( !this.lb )
				return <div key={i}>{it || '\u00a0'}</div>;

			if ( this.filtered && this.filtered.indexOf(this.items[i]) < 0 ) // this.filtered - массив с отфильтрованными элементами
				return null;

			this.last += 1;
			if ( this.state.sel === (this.last) )
				this.mainSel = i;
			return (
				<ListItem
					key={i}
					index={i}
					iShow={this.last}
					items={this.items}
					multi={this.multi}
					onclick={this.onclick}
					ondoubleclick={ this.btnClick }
					toggle={this.toggle}
					sel={ this.state.sel === (this.last) }
					ref={ o => { if (this.items) this.items[i].ref = o } }
					check={this.checked.includes(i)}
				/>);
		});
		let input = this.lb ?
			<div style={{padding: 4, color: '#004080', font: 'bold 9pt Arial'}}>
				{'Поиск'}
				<br/>
				<input
					className="dlgInput"
					ref={ o => this.input = o }
					onKeyDown={this.onkeydown}
					onChange={ this.onchange }
				/>
			</div>
			:
			null;

		return (
			<div className="dlgBG">
				<div
					className="dlgDiv"
					style={this.state.dlgDivStyle}
					onKeyDown={this.onkeydown}
					tabIndex="1"
				>
					<div className="dlgTitleBar">
						{this.title}
						<div className="dlgCloseButton" title="Закрыть" onClick={this.btnClick} >&times;</div>
					</div>
					<div style={{display: 'block', width: '100%'}}>
						<div
							className={ this.lb ? 'dlgList' : 'dlgData' }
							style={{...this.state.dlgDataStyle, display: 'inline-block'}}
						>
							{ this.header ? <b>{this.header}<br/>{'\u00a0'}<br/></b> : null }
							{list}
						</div>
						<div className="dlgButtons">
							<br/>
							{this.buttons}
						</div>
					</div>
					{input}
				</div>
			</div>
		);
	}
	//**************

};
//***********************
export default MsgBox
