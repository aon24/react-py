import React from 'react';
import ReactDOM from 'react-dom';

import Document from './Book/Document';


class Root extends React.Component {
	closeDoc = (doc, tidy) => {
		let ao = doc.getField('autoOrder');
		if ( ao && !tidy) {
			let rul = ao.split('>this')[0];
			window.location.href = [
				'/newdoc?' + doc.dbAlias,
				encodeURIComponent(rul),
				doc.dbAlias,
				doc.unid].join('&');
			return;
		}

		if ( doc.viewRefresh ) {
	        let opener = window.opener && !window.opener.closed && window.opener.top && !window.opener.top.closed ?
				window.opener.top
				:
				null;
			let viewWin = opener && opener.view && (opener.view.nocats || opener.view);
			viewWin && viewWin.viewRefresh && viewWin.viewRefresh(doc.unid);
		}
		window.close();
	};


	render = _ => {
		console.log('Sova.online 5.0, React', React.version);
		if ( !window.jsDoc )
			return <h2>Документ недоступен</h2>;

		return (
				<Document
					closeDoc={this.closeDoc}
					urlForm={window.jsDoc.urlForm}
					fieldValues={window.jsDoc.data ? {...window.jsDoc.data} : null}
					dbAlias={window.jsDoc.dbAlias}
					cssJsUrl={window.jsDoc.cssJsUrl}
					unid={window.jsDoc.unid}
					rsMode={window.jsDoc.rsMode}
					printList={window.jsDoc.printList}
					newForm={window.jsDoc.newForm}
					userName={(window.jsDoc.userName || '').split('::')[0]}
					owlDebug={window.owlDebug}
				/>
		);
	};
}

ReactDOM.render( <Root />, document.getElementById('root') );
