const proxy = require('http-proxy-middleware');

module.exports = function(app) {
    app.use(proxy("/dbopen", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/darkShow", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/upload", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/saveDoc", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/saveHour", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/download/", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/api.get", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/api.getc", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/api.post", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/docopen", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/image", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/form", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/jsv", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/js", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/list", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/alist", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/action", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/openasfile", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/newdoc", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/content", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
    app.use(proxy("/topic", {
        target: "http://127.0.0.1:8081",
        secure: false
    }));
  
};